# Process Engine — form + workflow in one editor

Replaces "pick a workflow template by amount threshold" with a **process graph owned by each form**, edited in a new **Process** tab next to your existing Form designer (modelled on UniFi's process engine: Start Process → activities with named outcomes → CompletedProcess).

## What's in the box

```text
src/types/process.ts                      Data model (activities, edges, variables, columns)
src/lib/process/activities.ts             Activity catalogue, ports, defaults, blankProcess()
src/lib/process/conditions.ts             Token resolver + AND/OR rule evaluation
src/lib/process/engine.ts                 Validation, auto-layout, simulator
src/lib/process/serialize.ts              Load/save normalisation + migrateWorkflowTemplate()
src/lib/process/refOptions.ts             Field/variable/record pickers from your sections
src/lib/process/processApi.ts             API calls to add to api.ts
src/components/process/TemplateEditorShell.tsx   Tabs: Form | Process | Preview | Default Columns
src/components/process/ProcessTab.tsx     Palette + canvas + Issues/Variables/Test run + undo/redo
src/components/process/ProcessCanvas.tsx  Drag/connect/zoom canvas (no graph library)
src/components/process/NodeConfigModal.tsx Settings for all 21 activity types
src/components/process/RuleGroupEditor.tsx Nested condition editor
src/components/process/ActivityPalette.tsx, VariablesPanel.tsx, SimulatorPanel.tsx,
  DefaultColumnsTab.tsx, icons.tsx, ui.tsx
```

Dependencies: `react`, `lucide-react`, and your `cn` helper at `@/lib/utils`. Copy `src/` into your project (`@/` alias = `src/`).

## Activities

Flow: Start Process, Wait, Sub Process, CompletedProcess, Terminate ·
People: Assignment, Notification ·
Conditions: If/Else, Switch, Fork, Join ·
Data: Set Value, Calculate, Get Current Record (GCR0…), Create Document, Expression Block ·
Integrations: Send HTTP Request / Background, Receive HTTP Request, Write HTTP Response, Data Connector (SunSystems journal stages, budget, PO).

Amount thresholds become a **Switch** (e.g. `< 50,000` / `50,000–500,000` / `> 500,000`) or `skipWhen` on an Assignment.

### Per-step form control
Each Assignment has **Form access at this step**: every section (and optionally each field) can be `Default`, `Editable`, `Read-only` or `Hidden`. This is what lets one template show differently to the requester, accounts and the approver.

### Tokens
`{{field.amount}}`, `{{var.vat}}`, `{{GCR0.status}}`, `{{ctx.initiator_name}}`, `{{ctx.now}}` — usable in conditions, emails, URLs, bodies and expressions.

## Wiring it in

```tsx
<TemplateEditorShell
  initial={template}
  groups={groups} users={users} templates={templateList} documentTypes={documentTypes}
  renderForm={({ template, onTemplateChange }) => (
    <TemplateBuilderV2 initial={template} onSave={() => {}} onChange={onTemplateChange} hideHeader />
  )}
  renderPreview={(t) => <DocumentFormRenderer template={t} />}
  onSave={({ template }) => templatesAPI.update(template.id!, template)}
/>
```

TemplateBuilderV2 needs two small changes: an `onChange(template)` callback fired when sections change, and a `hideHeader` flag (the shell owns name + Save).

Migrating existing forms: `migrateWorkflowTemplate(workflow.steps)` turns a linear workflow into a graph (approvals chain on Approved, all Rejected → Terminate). Store the old id in `process.settings.legacyWorkflowTemplateId`.

## Backend contract

Template payload gains two JSON columns: `process` (ProcessDefinition, `version: 3`) and `default_columns`.

Runtime engine (server, authoritative — the browser simulator is a design aid only):

1. **Submit** → create instance, seed variables, run from Start. Check `preconditions`.
2. **Run loop** — execute activity, pick outgoing edge by `fromPort`, repeat. Stop at an Assignment (create task), Wait, Receive HTTP, or a terminal.
3. **Assignment** — evaluate `skipWhen` / `autoApproveWhen` first (leave via `approved`). Resolve assignees by `assigneeType`. `group_all` completes when every member approves. Set document status to `statusLabel`. Schedule SLA + escalation (`escalated` port).
4. **Act** (`POST /documents/:id/process/act/`) — check the user is an assignee, require comment/signature if set, apply editable values allowed by `access`, continue from the chosen outcome.
5. **Returned** — document goes back to the initiator; on resubmit restart from Start if `restartOnResubmit`, otherwise resume at the returning node.
6. **Fork/Join** — run branches as parallel tokens; Join `all` waits for every inbound edge, `any` continues on the first.
7. **Access** (`GET /documents/:id/process/access/`) — merge the section's own rules with the current step's `access` for the current user; enforce the same on save (never trust the client).
8. **HTTP/connector** — run server-side with secrets referenced by name; `continueOnError` routes to `error`. Receive HTTP exposes `POST /api/public/process/<token>/<instanceId>` and verifies `secretHeader`.
9. **Completed/Terminate** — set `finalStatus`, lock if `lockDocument`, close open tasks.

Port the rule/token grammar in `conditions.ts` to your backend (Python: same operators, same `{{namespace.key}}` resolution).
