/**
 * process.ts — Process (backend engine) model for the form editor.
 *
 * This is the "Process" tab counterpart to your TemplateBuilderV2 "Form" tab.
 * A Template now owns its own executable process graph instead of pointing at
 * a separately-managed workflow template. Everything a form needs to travel
 * from submission to completion lives in one document:
 *
 *   Template
 *     ├── sections[]        (Form tab  — unchanged, your existing model)
 *     ├── process           (Process tab — this file)
 *     └── defaultColumns[]  (Default Columns tab)
 *
 * The graph is intentionally close to UniFi's activity model so the mental
 * model transfers: Start Process → activities → CompletedProcess, with each
 * activity exposing named outcomes ("Done", "Approved", "Rejected") that are
 * wired to the next activity.
 *
 * Compatibility note: RuleGroup / ConditionOperator are re-declared here with
 * the same shape used by TemplateBuilderV2 so this package can be dropped into
 * a project standalone. If you prefer a single source of truth, delete the
 * block marked `--- shared with TemplateBuilderV2 ---` and re-export those
 * types from your builder file instead.
 */

/* --- shared with TemplateBuilderV2 ------------------------------------- */

export type ConditionOperator =
  | "equals" | "not_equals" | "is_empty" | "is_not_empty"
  | "greater_than" | "greater_or_equal" | "less_than" | "less_or_equal"
  | "between" | "not_between"
  | "contains" | "not_contains" | "starts_with" | "ends_with"
  | "in_list" | "not_in_list"
  | "is_true" | "is_false";

/** What the left-hand side of a condition reads.
 *  - field        → a form field value (by KEY)
 *  - variable     → a process variable (by KEY)
 *  - record       → an aliased record loaded by a Get Current Record activity
 *                   ("GCR0.status")
 *  - context      → runtime context: initiator, current user, now, step count…
 *  - expression   → free token expression, evaluated with the same resolver */
export type ConditionSource = "field" | "variable" | "record" | "context" | "expression";

export interface ProcessCondition {
  source: ConditionSource;
  /** field key / variable key / "GCR0.total" / context key / raw expression */
  ref?: string;
  operator: ConditionOperator;
  value?: string;
  /** Optional second operand for between/not_between when not comma-encoded. */
  value2?: string;
}

export interface RuleGroup<C = ProcessCondition> {
  combinator: "and" | "or";
  conditions: C[];
  groups?: RuleGroup<C>[];
}

/* --- variables ---------------------------------------------------------- */

export type VariableType = "text" | "number" | "currency" | "boolean" | "date" | "json" | "user" | "list";

export interface ProcessVariable {
  id: string;
  key: string;
  label: string;
  type: VariableType;
  /** Literal or token expression evaluated once when the instance starts. */
  initial?: string;
  description?: string;
  /** Exposed on the document detail page / API payload. */
  exposed?: boolean;
}

/* --- activities --------------------------------------------------------- */

export type ActivityType =
  | "start"
  | "assignment"
  | "notification"
  | "set_value"
  | "calculate"
  | "if_else"
  | "switch"
  | "get_record"
  | "fork"
  | "join"
  | "http_request"
  | "http_background"
  | "http_receive"
  | "http_response"
  | "data_connector"
  | "delay"
  | "create_document"
  | "sub_process"
  | "script"
  | "completed"
  | "terminate";

/* ---- per-type configuration ---- */

export type AssigneeType =
  | "group_any"        // anyone in the group may action it
  | "group_all"        // every member must action it
  | "group_specific"   // a named user inside a group
  | "user"             // a named user
  | "initiator"        // whoever submitted the form
  | "field_user"       // a user picked in a form field (user/reference field)
  | "manager"          // the initiator's line manager
  | "variable";        // a user id held in a process variable

/** Per-step control over the FORM itself — the reason for merging the two
 *  builders. At this step, each section (and optionally each field) can be
 *  hidden, read-only or editable, so the same template renders differently to
 *  the requester, accounts and the approver. */
export interface StepAccessRule {
  /** Section id from Template.sections, or "field:<fieldKey>" for one field. */
  target: string;
  mode: "hidden" | "readonly" | "editable";
}

export interface EscalationConfig {
  enabled: boolean;
  afterHours: number;
  action: "notify" | "reassign" | "auto_approve" | "auto_reject";
  notifyGroup?: string | null;
  notifyUser?: string | null;
  reassignGroup?: string | null;
  reassignUser?: string | null;
}

export interface AssignmentConfig {
  /** Status shown on the document while it waits here ("Accounts Approval"). */
  statusLabel: string;
  assigneeType: AssigneeType;
  assigneeGroup?: string | null;
  assigneeGroupName?: string;
  assigneeUser?: string | null;
  assigneeUserName?: string;
  /** For assigneeType "field_user" / "variable". */
  assigneeRef?: string;
  slaHours: number;
  allowApprove: boolean;
  allowReject: boolean;
  allowReturn: boolean;
  allowResubmit: boolean;
  allowDelegate?: boolean;
  requiresSignature: boolean;
  requireComment?: boolean;
  /** Skip this step entirely when the rule matches (e.g. amount < 50,000). */
  skipWhen?: RuleGroup | null;
  /** Auto-approve without human action when the rule matches. */
  autoApproveWhen?: RuleGroup | null;
  instructions?: string;
  approverEmailSubject?: string;
  approverEmailBody?: string;
  /** Per-step form access (the UniFi "stage permissions" behaviour). */
  access?: StepAccessRule[];
  escalation?: EscalationConfig | null;
}

export type NotificationChannel = "email" | "in_app" | "both";

export interface NotificationConfig {
  channel: NotificationChannel;
  toUsers?: string[];
  toGroups?: string[];
  toEmails?: string[];
  /** Form field KEYs holding an email address or a user reference. */
  toFieldKeys?: string[];
  toInitiator?: boolean;
  subject: string;
  body: string;
  includeItemsTable?: boolean;
  /** Attach the generated document/PDF to the email. */
  attachDocument?: boolean;
  sendWhen?: RuleGroup | null;
}

export type ValueMode = "constant" | "expression" | "field" | "variable" | "record" | "formula";

export interface ValueAssignment {
  id: string;
  /** "field:<key>" or "var:<key>" — what receives the value. */
  target: string;
  mode: ValueMode;
  /** Literal, token expression ("{{field.amount}} * 0.16"), key, or formula. */
  value: string;
  /** Only assign when this matches. */
  when?: RuleGroup | null;
}

export interface SetValueConfig {
  assignments: ValueAssignment[];
}

export interface CalculateConfig {
  /** "field:<key>" or "var:<key>". */
  target: string;
  /** Arithmetic over field/variable tokens — same grammar as your calc fields. */
  expression: string;
  decimals?: number;
}

export interface IfElseConfig {
  rules: RuleGroup;
  /** Labels shown on the two outgoing ports. */
  trueLabel?: string;
  falseLabel?: string;
}

export interface SwitchCase {
  id: string;
  label: string;
  rules: RuleGroup;
}

export interface SwitchConfig {
  cases: SwitchCase[];
  /** Emits the "default" port when no case matches. */
  hasDefault?: boolean;
}

export type RecordSource = "current" | "related" | "lookup" | "initiator" | "api";

export interface GetRecordConfig {
  /** Alias used by later activities — "GCR0", "GCR1"… */
  alias: string;
  source: RecordSource;
  /** For "related"/"lookup": document type or dataset to read from. */
  documentTypeId?: string | null;
  /** Field keys (or dotted paths) copied into the alias scope. */
  fields: string[];
  /** For "lookup": match rule, e.g. reference_number equals {{field.po_ref}}. */
  match?: RuleGroup | null;
  /** Fail the branch when nothing is found (otherwise the alias is empty). */
  requireMatch?: boolean;
}

export interface ForkConfig {
  branches: { id: string; label: string }[];
}

export interface JoinConfig {
  /** "all" waits for every inbound branch; "any" continues on the first. */
  mode: "all" | "any";
}

export interface HttpHeader { id: string; name: string; value: string }

export interface HttpResponseMapping {
  id: string;
  /** Dotted path into the JSON response ("data.items.0.id"). */
  path: string;
  /** "field:<key>" or "var:<key>". */
  target: string;
}

export interface HttpConfig {
  method: "GET" | "POST" | "PUT" | "PATCH" | "DELETE";
  url: string;
  headers: HttpHeader[];
  /** Token-interpolated JSON body. */
  body?: string;
  auth?: { type: "none" | "basic" | "bearer" | "api_key"; ref?: string };
  timeoutSeconds?: number;
  /** Retry policy for background sends. */
  retries?: number;
  responseMapping?: HttpResponseMapping[];
  /** Branch to the "error" port instead of failing the instance. */
  continueOnError?: boolean;
}

export interface HttpReceiveConfig {
  /** Public path suffix — the engine exposes /api/public/process/<token>. */
  token: string;
  /** Shared-secret header name/value pair used to authenticate the caller. */
  secretHeader?: string;
  mapping?: HttpResponseMapping[];
  /** How long the instance waits before timing out on the "timeout" port. */
  timeoutHours?: number;
}

export interface HttpResponseConfig {
  status: number;
  body?: string;
  contentType?: string;
}

export interface DataConnectorConfig {
  /** "sunsystems_journal" | "sunsystems_budget" | "sunsystems_po" | custom id */
  connector: string;
  label?: string;
  /** For staged journal posting — matches SunSystemsUi.journalStages[].stage */
  stage?: number;
  /** Extra key/value parameters passed straight to the connector. */
  parameters?: { id: string; name: string; value: string }[];
  /** Put the connector's response into fields/variables. */
  mapping?: HttpResponseMapping[];
  runWhen?: RuleGroup | null;
  continueOnError?: boolean;
}

export interface DelayConfig {
  mode: "duration" | "until_date";
  hours?: number;
  /** For "until_date": a date field/variable token. */
  untilRef?: string;
  /** Business hours only. */
  workingHours?: boolean;
}

export interface CreateDocumentConfig {
  templateId: string;
  titleExpression?: string;
  documentTypeId?: string | null;
  /** Copy values from this form into the new one. */
  mapping?: { id: string; from: string; to: string }[];
  /** Start the new document's own process immediately. */
  startProcess?: boolean;
}

export interface SubProcessConfig {
  /** Another template's process, run to completion before continuing. */
  templateId: string;
  waitForCompletion: boolean;
  mapping?: { id: string; from: string; to: string }[];
}

export interface ScriptConfig {
  /** Server-side sandboxed expression list — one assignment per line. */
  body: string;
  language: "expression";
}

export interface CompletedConfig {
  finalStatus: string;
  message?: string;
  /** Lock the document from further edits. */
  lockDocument?: boolean;
}

export interface TerminateConfig {
  finalStatus: string;
  reason?: string;
}

export interface StartConfig {
  /** Status the document carries the moment it is submitted. */
  statusLabel: string;
  /** Validate these rules before the process may start. */
  preconditions?: RuleGroup | null;
  /** Allow saving as draft before submission. */
  allowDraft?: boolean;
}

export type ActivityConfig =
  | ({ kind: "start" } & StartConfig)
  | ({ kind: "assignment" } & AssignmentConfig)
  | ({ kind: "notification" } & NotificationConfig)
  | ({ kind: "set_value" } & SetValueConfig)
  | ({ kind: "calculate" } & CalculateConfig)
  | ({ kind: "if_else" } & IfElseConfig)
  | ({ kind: "switch" } & SwitchConfig)
  | ({ kind: "get_record" } & GetRecordConfig)
  | ({ kind: "fork" } & ForkConfig)
  | ({ kind: "join" } & JoinConfig)
  | ({ kind: "http_request" } & HttpConfig)
  | ({ kind: "http_background" } & HttpConfig)
  | ({ kind: "http_receive" } & HttpReceiveConfig)
  | ({ kind: "http_response" } & HttpResponseConfig)
  | ({ kind: "data_connector" } & DataConnectorConfig)
  | ({ kind: "delay" } & DelayConfig)
  | ({ kind: "create_document" } & CreateDocumentConfig)
  | ({ kind: "sub_process" } & SubProcessConfig)
  | ({ kind: "script" } & ScriptConfig)
  | ({ kind: "completed" } & CompletedConfig)
  | ({ kind: "terminate" } & TerminateConfig);

export interface ProcessNode {
  id: string;
  type: ActivityType;
  /** Short code shown in the card body ("GCR0", "OrgReconCheck"). */
  name: string;
  description?: string;
  x: number;
  y: number;
  config: ActivityConfig;
  /** Collapsed cards render title-only. */
  collapsed?: boolean;
  /** Purely visual — inherited from ACTIVITY_META when absent. */
  accent?: string;
}

export interface ProcessEdge {
  id: string;
  from: string;
  /** Outgoing port id on the source node — "done", "approved", "true"… */
  fromPort: string;
  to: string;
  label?: string;
}

export interface ProcessSettings {
  /** Amount-threshold routing lives inside the graph now, but keeping the
   *  legacy hook makes migration from workflow templates lossless. */
  legacyWorkflowTemplateId?: string | null;
  /** Re-run the whole process from Start when a returned form is resubmitted;
   *  otherwise resume at the step that returned it. */
  restartOnResubmit?: boolean;
  /** Cancel the instance if it exceeds this many hours end-to-end. */
  instanceSlaHours?: number;
  /** Notify the initiator on every status change. */
  notifyInitiatorOnStatusChange?: boolean;
}

export interface ProcessDefinition {
  /** Bumped by serialize() — lets the backend migrate old payloads. */
  version: number;
  nodes: ProcessNode[];
  edges: ProcessEdge[];
  variables: ProcessVariable[];
  settings: ProcessSettings;
}

/* --- default / output columns (4th tab) --------------------------------- */

export interface DefaultColumn {
  id: string;
  /** Form field KEY, "var:<key>", or a system column ("status", "created_at"). */
  ref: string;
  label: string;
  width?: number;
  visible: boolean;
  sortable?: boolean;
  filterable?: boolean;
  align?: "left" | "center" | "right";
  format?: "text" | "number" | "currency" | "date" | "datetime" | "boolean" | "status" | "user";
}

/* --- validation --------------------------------------------------------- */

export interface ValidationIssue {
  level: "error" | "warning";
  nodeId?: string;
  edgeId?: string;
  message: string;
}

/* --- simulation --------------------------------------------------------- */

export interface SimulationStep {
  nodeId: string;
  nodeName: string;
  type: ActivityType;
  detail: string;
  /** Port the engine left through. */
  outPort?: string;
  /** Waiting on a human — the simulator pauses here for a decision. */
  awaiting?: boolean;
  status?: string;
}

export interface SimulationState {
  values: Record<string, unknown>;
  variables: Record<string, unknown>;
  records: Record<string, Record<string, unknown>>;
  trace: SimulationStep[];
  finished: boolean;
  finalStatus?: string;
  error?: string;
}
