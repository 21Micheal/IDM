/**
 * ActivityPalette.tsx — left rail of the Process tab. Drag an activity onto
 * the canvas (HTML5 DnD, mime "application/x-process-activity") or click to
 * drop it at the centre of the viewport.
 */

import { useMemo, useState } from "react";
import { Search } from "lucide-react";
import type { ActivityType } from "@/types/process";
import { ACTIVITY_GROUPS, ACTIVITY_META } from "@/lib/process/activities";
import { ActivityIcon } from "./icons";
import { cn } from "@/lib/utils";

export const ACTIVITY_DND_MIME = "application/x-process-activity";

export function ActivityPalette({
  onAdd, hasStart,
}: { onAdd: (type: ActivityType) => void; hasStart: boolean }) {
  const [q, setQ] = useState("");
  const items = useMemo(() => {
    const term = q.trim().toLowerCase();
    return Object.values(ACTIVITY_META).filter(
      (m) => !term || m.label.toLowerCase().includes(term) || m.description.toLowerCase().includes(term),
    );
  }, [q]);

  return (
    <aside className="flex h-full w-64 shrink-0 flex-col border-r border-slate-200 bg-white">
      <div className="border-b border-slate-200 p-3">
        <h3 className="mb-2 text-xs font-semibold uppercase tracking-wide text-slate-500">Activities</h3>
        <div className="relative">
          <Search className="pointer-events-none absolute left-2 top-2 h-4 w-4 text-slate-400" />
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Search activities"
            className="w-full rounded-md border border-slate-300 py-1.5 pl-8 pr-2 text-sm outline-none focus:border-sky-400"
          />
        </div>
      </div>
      <div className="flex-1 overflow-y-auto p-2">
        {ACTIVITY_GROUPS.map((g) => {
          const groupItems = items.filter((m) => m.group === g.id);
          if (!groupItems.length) return null;
          return (
            <div key={g.id} className="mb-3">
              <div className="px-1 pb-1 text-[11px] font-semibold uppercase tracking-wide text-slate-400">{g.label}</div>
              {groupItems.map((m) => {
                const disabled = m.singleton && m.type === "start" && hasStart;
                return (
                  <button
                    key={m.type}
                    type="button"
                    disabled={disabled}
                    draggable={!disabled}
                    onDragStart={(e) => {
                      e.dataTransfer.setData(ACTIVITY_DND_MIME, m.type);
                      e.dataTransfer.effectAllowed = "copy";
                    }}
                    onClick={() => onAdd(m.type)}
                    title={m.description}
                    className={cn(
                      "mb-1 flex w-full items-start gap-2 rounded-md border px-2 py-1.5 text-left transition",
                      m.accent,
                      disabled ? "cursor-not-allowed opacity-40" : "cursor-grab hover:shadow-sm active:cursor-grabbing",
                    )}
                  >
                    <ActivityIcon name={m.icon} className="mt-0.5 h-4 w-4 shrink-0" />
                    <span className="min-w-0">
                      <span className="block truncate text-sm font-medium">{m.label}</span>
                      <span className="block truncate text-[11px] opacity-70">{m.description}</span>
                    </span>
                  </button>
                );
              })}
            </div>
          );
        })}
      </div>
    </aside>
  );
}
