/**
 * DefaultColumnsTab.tsx — 4th editor tab: which columns the document list for
 * this template shows by default (form fields, variables, system columns).
 */

import { ArrowDown, ArrowUp, Plus, Trash2 } from "lucide-react";
import type { DefaultColumn, ProcessDefinition } from "@/types/process";
import { uid } from "@/lib/process/activities";
import { formFields, type ProcessFormSection } from "@/lib/process/refOptions";
import { Button, Select, TextInput } from "./ui";

const SYSTEM: { ref: string; label: string; format: DefaultColumn["format"] }[] = [
  { ref: "document_number", label: "Document No.", format: "text" },
  { ref: "status", label: "Status", format: "status" },
  { ref: "current_assignee", label: "Waiting on", format: "user" },
  { ref: "created_by", label: "Initiator", format: "user" },
  { ref: "created_at", label: "Created", format: "datetime" },
  { ref: "updated_at", label: "Last updated", format: "datetime" },
  { ref: "sla_due_at", label: "SLA due", format: "datetime" },
];

export function DefaultColumnsTab({
  columns, onChange, sections, process,
}: { columns: DefaultColumn[]; onChange: (c: DefaultColumn[]) => void; sections: ProcessFormSection[]; process: ProcessDefinition }) {
  const options = [
    ...SYSTEM.map((s) => ({ ref: s.ref, label: s.label, group: "System", format: s.format })),
    ...formFields(sections).map((f) => ({
      ref: f.key, label: f.label, group: `Form · ${f.section}`,
      format: (f.type === "currency" ? "currency" : f.type === "number" ? "number" : f.type === "date" ? "date" : f.type === "boolean" ? "boolean" : "text") as DefaultColumn["format"],
    })),
    ...process.variables.map((v) => ({ ref: `var:${v.key}`, label: v.label, group: "Variables", format: (v.type === "currency" ? "currency" : "text") as DefaultColumn["format"] })),
  ];
  const used = new Set(columns.map((c) => c.ref));
  const update = (i: number, patch: Partial<DefaultColumn>) => onChange(columns.map((c, j) => (j === i ? { ...c, ...patch } : c)));
  const move = (i: number, d: -1 | 1) => {
    const n = [...columns];
    const j = i + d;
    if (j < 0 || j >= n.length) return;
    [n[i], n[j]] = [n[j], n[i]];
    onChange(n);
  };
  const groups = [...new Set(options.map((o) => o.group))];

  return (
    <div className="mx-auto max-w-5xl p-6">
      <div className="mb-4 flex items-center gap-3">
        <div>
          <h2 className="text-base font-semibold text-slate-900">Default columns</h2>
          <p className="text-xs text-slate-500">Columns shown in the document list for this form. Users can still personalise their view.</p>
        </div>
        <Select
          className="ml-auto w-72"
          value=""
          onChange={(e) => {
            const o = options.find((x) => x.ref === e.target.value);
            if (o) onChange([...columns, { id: uid("col"), ref: o.ref, label: o.label, visible: true, sortable: true, filterable: false, align: o.format === "currency" || o.format === "number" ? "right" : "left", format: o.format }]);
          }}
        >
          <option value="">+ Add column…</option>
          {groups.map((g) => (
            <optgroup key={g} label={g}>
              {options.filter((o) => o.group === g && !used.has(o.ref)).map((o) => <option key={o.ref} value={o.ref}>{o.label}</option>)}
            </optgroup>
          ))}
        </Select>
        <Button onClick={() => onChange(SYSTEM.slice(0, 5).map((s) => ({ id: uid("col"), ref: s.ref, label: s.label, visible: true, sortable: true, align: "left", format: s.format })))}>
          <Plus className="h-3.5 w-3.5" /> Defaults
        </Button>
      </div>

      <div className="overflow-hidden rounded-lg border border-slate-200 bg-white">
        <table className="w-full text-sm">
          <thead className="bg-slate-50 text-left text-[11px] uppercase tracking-wide text-slate-500">
            <tr>
              <th className="px-3 py-2">Order</th><th className="px-3 py-2">Source</th><th className="px-3 py-2">Label</th>
              <th className="px-3 py-2">Format</th><th className="px-3 py-2">Align</th><th className="px-3 py-2">Width</th>
              <th className="px-3 py-2 text-center">Visible</th><th className="px-3 py-2 text-center">Sort</th><th className="px-3 py-2 text-center">Filter</th><th />
            </tr>
          </thead>
          <tbody>
            {columns.map((c, i) => (
              <tr key={c.id} className="border-t border-slate-100">
                <td className="px-3 py-1.5">
                  <div className="flex gap-0.5">
                    <button type="button" onClick={() => move(i, -1)} className="text-slate-400 hover:text-slate-700"><ArrowUp className="h-3.5 w-3.5" /></button>
                    <button type="button" onClick={() => move(i, 1)} className="text-slate-400 hover:text-slate-700"><ArrowDown className="h-3.5 w-3.5" /></button>
                  </div>
                </td>
                <td className="px-3 py-1.5 font-mono text-xs text-slate-500">{c.ref}</td>
                <td className="px-3 py-1.5"><TextInput className="py-1" value={c.label} onChange={(e) => update(i, { label: e.target.value })} /></td>
                <td className="px-3 py-1.5">
                  <Select className="py-1" value={c.format} onChange={(e) => update(i, { format: e.target.value as DefaultColumn["format"] })}>
                    {["text", "number", "currency", "date", "datetime", "boolean", "status", "user"].map((f) => <option key={f}>{f}</option>)}
                  </Select>
                </td>
                <td className="px-3 py-1.5">
                  <Select className="py-1" value={c.align} onChange={(e) => update(i, { align: e.target.value as DefaultColumn["align"] })}>
                    <option>left</option><option>center</option><option>right</option>
                  </Select>
                </td>
                <td className="px-3 py-1.5"><TextInput className="w-20 py-1" type="number" value={c.width ?? ""} onChange={(e) => update(i, { width: Number(e.target.value) || undefined })} /></td>
                <td className="text-center"><input type="checkbox" checked={c.visible} onChange={(e) => update(i, { visible: e.target.checked })} /></td>
                <td className="text-center"><input type="checkbox" checked={!!c.sortable} onChange={(e) => update(i, { sortable: e.target.checked })} /></td>
                <td className="text-center"><input type="checkbox" checked={!!c.filterable} onChange={(e) => update(i, { filterable: e.target.checked })} /></td>
                <td className="px-2"><button type="button" onClick={() => onChange(columns.filter((_, j) => j !== i))} className="text-slate-400 hover:text-rose-500"><Trash2 className="h-4 w-4" /></button></td>
              </tr>
            ))}
            {!columns.length && <tr><td colSpan={10} className="px-3 py-6 text-center text-xs text-slate-400">No columns yet — add one or click “Defaults”.</td></tr>}
          </tbody>
        </table>
      </div>
    </div>
  );
}
