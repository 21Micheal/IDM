/**
 * RuleGroupEditor.tsx — nested AND/OR condition editor used everywhere a
 * ProcessDefinition needs a rule: If/Else, Switch cases, skip/auto-approve,
 * conditional notifications, connector run-conditions, per-assignment guards.
 *
 * It is the process-tab twin of the visibility rule editor already in your
 * form builder, but its left-hand side can also read process variables,
 * Get-Current-Record aliases and runtime context — not just form fields.
 */

import { Plus, Trash2, CornerDownRight } from "lucide-react";
import type { ConditionOperator, ProcessCondition, RuleGroup } from "@/types/process";
import { Button, Select, TextInput } from "./ui";
import { cn } from "@/lib/utils";

const OPERATORS: { id: ConditionOperator; label: string }[] = [
  { id: "equals", label: "equals" },
  { id: "not_equals", label: "does not equal" },
  { id: "greater_than", label: "is greater than" },
  { id: "greater_or_equal", label: "is greater or equal" },
  { id: "less_than", label: "is less than" },
  { id: "less_or_equal", label: "is less or equal" },
  { id: "between", label: "is between" },
  { id: "not_between", label: "is not between" },
  { id: "contains", label: "contains" },
  { id: "not_contains", label: "does not contain" },
  { id: "starts_with", label: "starts with" },
  { id: "ends_with", label: "ends with" },
  { id: "in_list", label: "is one of" },
  { id: "not_in_list", label: "is not one of" },
  { id: "is_empty", label: "is empty" },
  { id: "is_not_empty", label: "is not empty" },
  { id: "is_true", label: "is true" },
  { id: "is_false", label: "is false" },
];

const VALUELESS = new Set<ConditionOperator>(["is_empty", "is_not_empty", "is_true", "is_false"]);
const RANGE = new Set<ConditionOperator>(["between", "not_between"]);

export interface RefOption { value: string; label: string; group: string }

export interface RuleGroupEditorProps {
  group: RuleGroup;
  onChange: (g: RuleGroup) => void;
  /** Field keys, variables, record aliases and context values to choose from. */
  refOptions: RefOption[];
  depth?: number;
}

function emptyCondition(refOptions: RefOption[]): ProcessCondition {
  const first = refOptions[0];
  return { source: sourceOf(first?.value ?? "field."), ref: first?.value ?? "", operator: "equals", value: "" };
}

function sourceOf(ref: string): ProcessCondition["source"] {
  if (ref.startsWith("var.")) return "variable";
  if (ref.startsWith("ctx.")) return "context";
  if (ref.startsWith("field.")) return "field";
  if (/^[A-Z]{2,}\d*\./.test(ref)) return "record";
  return "field";
}

export function RuleGroupEditor({ group, onChange, refOptions, depth = 0 }: RuleGroupEditorProps) {
  const setCondition = (i: number, patch: Partial<ProcessCondition>) => {
    const conditions = group.conditions.map((c, idx) => (idx === i ? { ...c, ...patch } : c));
    onChange({ ...group, conditions });
  };

  const grouped = refOptions.reduce<Record<string, RefOption[]>>((acc, o) => {
    (acc[o.group] ||= []).push(o);
    return acc;
  }, {});

  return (
    <div className={cn("rounded-lg border border-slate-200 bg-slate-50/60 p-3", depth > 0 && "mt-2")}>
      <div className="mb-2 flex items-center gap-2">
        <span className="text-[11px] font-semibold uppercase tracking-wide text-slate-500">Match</span>
        <div className="inline-flex overflow-hidden rounded-md border border-slate-300">
          {(["and", "or"] as const).map((c) => (
            <button
              key={c}
              type="button"
              onClick={() => onChange({ ...group, combinator: c })}
              className={cn(
                "px-2.5 py-1 text-xs font-medium",
                group.combinator === c ? "bg-sky-600 text-white" : "bg-white text-slate-600 hover:bg-slate-50",
              )}
            >
              {c.toUpperCase()}
            </button>
          ))}
        </div>
        <span className="text-[11px] text-slate-400">
          {group.combinator === "and" ? "every condition must match" : "any condition may match"}
        </span>
      </div>

      <div className="space-y-2">
        {group.conditions.map((cond, i) => (
          <div key={i} className="flex flex-wrap items-center gap-2 rounded-md border border-slate-200 bg-white p-2">
            <Select
              className="w-56"
              value={cond.ref ?? ""}
              onChange={(e) => setCondition(i, { ref: e.target.value, source: sourceOf(e.target.value) })}
            >
              <option value="">Select a value…</option>
              {Object.entries(grouped).map(([groupName, opts]) => (
                <optgroup key={groupName} label={groupName}>
                  {opts.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
                </optgroup>
              ))}
            </Select>

            <Select
              className="w-44"
              value={cond.operator}
              onChange={(e) => setCondition(i, { operator: e.target.value as ConditionOperator })}
            >
              {OPERATORS.map((o) => <option key={o.id} value={o.id}>{o.label}</option>)}
            </Select>

            {!VALUELESS.has(cond.operator) && (
              <>
                <TextInput
                  className="w-40"
                  value={cond.value ?? ""}
                  placeholder={RANGE.has(cond.operator) ? "From" : "Value or {{field.key}}"}
                  onChange={(e) => setCondition(i, { value: e.target.value })}
                />
                {RANGE.has(cond.operator) && (
                  <TextInput
                    className="w-32"
                    value={cond.value2 ?? ""}
                    placeholder="To"
                    onChange={(e) => setCondition(i, { value2: e.target.value })}
                  />
                )}
              </>
            )}

            <button
              type="button"
              className="ml-auto rounded p-1 text-slate-400 hover:bg-rose-50 hover:text-rose-500"
              onClick={() => onChange({ ...group, conditions: group.conditions.filter((_, idx) => idx !== i) })}
            >
              <Trash2 className="h-4 w-4" />
            </button>
          </div>
        ))}

        {(group.groups ?? []).map((sub, i) => (
          <div key={i} className="flex gap-2">
            <CornerDownRight className="mt-3 h-4 w-4 shrink-0 text-slate-300" />
            <div className="flex-1">
              <RuleGroupEditor
                group={sub}
                depth={depth + 1}
                refOptions={refOptions}
                onChange={(g) => onChange({ ...group, groups: (group.groups ?? []).map((x, idx) => (idx === i ? g : x)) })}
              />
              <button
                type="button"
                className="mt-1 text-[11px] text-rose-500 hover:underline"
                onClick={() => onChange({ ...group, groups: (group.groups ?? []).filter((_, idx) => idx !== i) })}
              >
                Remove group
              </button>
            </div>
          </div>
        ))}
      </div>

      <div className="mt-2 flex gap-2">
        <Button onClick={() => onChange({ ...group, conditions: [...group.conditions, emptyCondition(refOptions)] })}>
          <Plus className="h-3.5 w-3.5" /> Condition
        </Button>
        {depth < 2 && (
          <Button
            variant="ghost"
            onClick={() => onChange({
              ...group,
              groups: [...(group.groups ?? []), { combinator: "or", conditions: [emptyCondition(refOptions)], groups: [] }],
            })}
          >
            <Plus className="h-3.5 w-3.5" /> Nested group
          </Button>
        )}
      </div>
    </div>
  );
}
