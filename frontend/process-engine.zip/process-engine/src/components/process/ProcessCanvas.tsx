/**
 * ProcessCanvas.tsx — the visual graph editor (UniFi-style activity cards).
 *
 *  - Drag a card by its header to move it (snaps to a 20px grid).
 *  - Drag from an outcome port (bottom of a card) onto another card to connect.
 *  - Drag the empty background to pan; Ctrl/⌘ + wheel (or the +/- buttons) to zoom.
 *  - Click a connection to select it, Delete/Backspace removes the selection.
 *  - Double-click a card to open its settings.
 *  - Drop palette items anywhere on the canvas.
 *
 * Pure React + SVG — no graph library dependency.
 */

import { useCallback, useEffect, useRef, useState } from "react";
import { Copy, Maximize2, Minus, Plus, Settings2, Trash2, Wand2 } from "lucide-react";
import type { ActivityType, ProcessDefinition, ProcessEdge, ProcessNode, ValidationIssue } from "@/types/process";
import { ACTIVITY_META, portsForNode, uid, type Port } from "@/lib/process/activities";
import { describeRuleGroup } from "@/lib/process/conditions";
import { describeAssignee } from "@/lib/process/engine";
import { ACTIVITY_DND_MIME } from "./ActivityPalette";
import { ActivityIcon } from "./icons";
import { cn } from "@/lib/utils";

export const NODE_W = 260;
const HEADER_H = 34;
const BODY_H = 64;
const PORTS_H = 30;
export const NODE_H = HEADER_H + BODY_H + PORTS_H;
const GRID = 20;

const snap = (v: number) => Math.round(v / GRID) * GRID;

const TONE: Record<Port["tone"], string> = {
  neutral: "#64748b",
  positive: "#059669",
  negative: "#e11d48",
  warning: "#d97706",
};

export interface ProcessCanvasProps {
  def: ProcessDefinition;
  onChange: (def: ProcessDefinition) => void;
  selectedId: string | null;
  onSelect: (id: string | null) => void;
  onOpen: (id: string) => void;
  onDropActivity: (type: ActivityType, x: number, y: number) => void;
  onAutoLayout: () => void;
  issues: ValidationIssue[];
  /** Node ids lit up by the simulator trace. */
  highlight?: string[];
  activeNodeId?: string | null;
}

function portPos(node: ProcessNode, portIndex: number, count: number) {
  const step = NODE_W / (count + 1);
  return { x: node.x + step * (portIndex + 1), y: node.y + NODE_H };
}

function edgePath(x1: number, y1: number, x2: number, y2: number) {
  const dy = Math.max(40, Math.abs(y2 - y1) / 2);
  // Back-edges (loops, e.g. "Returned" to an earlier step) curve out sideways.
  if (y2 < y1 + 10) {
    const side = x2 <= x1 ? -1 : 1;
    const bulge = 120 * side;
    return `M ${x1} ${y1} C ${x1} ${y1 + 80}, ${x1 + bulge} ${y1 + 80}, ${(x1 + x2) / 2 + bulge} ${(y1 + y2) / 2} S ${x2} ${y2 - 80}, ${x2} ${y2}`;
  }
  return `M ${x1} ${y1} C ${x1} ${y1 + dy}, ${x2} ${y2 - dy}, ${x2} ${y2}`;
}

function summary(node: ProcessNode): string {
  const c = node.config;
  switch (c.kind) {
    case "start": return `Status: ${c.statusLabel}`;
    case "assignment": return `${c.statusLabel} · ${describeAssignee(c)}${c.slaHours ? ` · ${c.slaHours}h SLA` : ""}`;
    case "notification": return c.subject ? `“${c.subject}”` : "No subject";
    case "set_value": return `${c.assignments?.length ?? 0} assignment(s)`;
    case "calculate": return c.target ? `${c.target} = ${c.expression}` : "Not configured";
    case "if_else": return describeRuleGroup(c.rules) || "No condition";
    case "switch": return `${c.cases?.length ?? 0} case(s)${c.hasDefault ? " + default" : ""}`;
    case "get_record": return `${c.alias} · ${c.source} · ${c.fields?.length ?? 0} field(s)`;
    case "fork": return `${c.branches?.length ?? 0} parallel branches`;
    case "join": return c.mode === "all" ? "Wait for all branches" : "Continue on first branch";
    case "http_request":
    case "http_background": return `${c.method} ${c.url || "—"}`;
    case "http_receive": return `/api/public/process/${c.token}`;
    case "http_response": return `HTTP ${c.status}`;
    case "data_connector": return `${c.label || c.connector}${c.stage ? ` · stage ${c.stage}` : ""}`;
    case "delay": return c.mode === "duration" ? `${c.hours ?? 0}h${c.workingHours ? " (working)" : ""}` : `Until ${c.untilRef || "—"}`;
    case "create_document": return c.templateId ? `Template ${c.templateId}` : "No template";
    case "sub_process": return c.templateId ? `Template ${c.templateId}` : "No template";
    case "script": return `${(c.body ?? "").split("\n").filter(Boolean).length} line(s)`;
    case "completed": return `Final status: ${c.finalStatus}`;
    case "terminate": return `Final status: ${c.finalStatus}`;
    default: return "";
  }
}

type Drag =
  | { kind: "node"; id: string; dx: number; dy: number; moved: boolean }
  | { kind: "pan"; sx: number; sy: number; ox: number; oy: number }
  | { kind: "edge"; from: string; port: string; x: number; y: number };

export function ProcessCanvas({
  def, onChange, selectedId, onSelect, onOpen, onDropActivity, onAutoLayout, issues, highlight = [], activeNodeId,
}: ProcessCanvasProps) {
  const wrapRef = useRef<HTMLDivElement>(null);
  const [view, setView] = useState({ x: 0, y: 0, k: 0.9 });
  const [drag, setDrag] = useState<Drag | null>(null);
  const [selectedEdge, setSelectedEdge] = useState<string | null>(null);
  const [hoverTarget, setHoverTarget] = useState<string | null>(null);

  const toWorld = useCallback((clientX: number, clientY: number) => {
    const r = wrapRef.current!.getBoundingClientRect();
    return { x: (clientX - r.left - view.x) / view.k, y: (clientY - r.top - view.y) / view.k };
  }, [view]);

  const byId = new Map(def.nodes.map((n) => [n.id, n]));
  const issueByNode = new Map<string, ValidationIssue["level"]>();
  for (const i of issues) {
    if (!i.nodeId) continue;
    if (i.level === "error" || !issueByNode.has(i.nodeId)) issueByNode.set(i.nodeId, i.level);
  }

  /* ── keyboard ── */
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const tag = (e.target as HTMLElement)?.tagName;
      if (tag === "INPUT" || tag === "TEXTAREA" || tag === "SELECT") return;
      if (e.key !== "Delete" && e.key !== "Backspace") return;
      if (selectedEdge) {
        onChange({ ...def, edges: def.edges.filter((x) => x.id !== selectedEdge) });
        setSelectedEdge(null);
      } else if (selectedId) {
        const n = byId.get(selectedId);
        if (n?.type === "start") return;
        onChange({
          ...def,
          nodes: def.nodes.filter((x) => x.id !== selectedId),
          edges: def.edges.filter((x) => x.from !== selectedId && x.to !== selectedId),
        });
        onSelect(null);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  });

  /* ── pointer handling ── */
  const onPointerMove = (e: React.PointerEvent) => {
    if (!drag) return;
    if (drag.kind === "pan") {
      setView((v) => ({ ...v, x: drag.ox + e.clientX - drag.sx, y: drag.oy + e.clientY - drag.sy }));
    } else if (drag.kind === "node") {
      const p = toWorld(e.clientX, e.clientY);
      const nx = snap(p.x - drag.dx);
      const ny = snap(p.y - drag.dy);
      onChange({ ...def, nodes: def.nodes.map((n) => (n.id === drag.id ? { ...n, x: nx, y: ny } : n)) });
      if (!drag.moved) setDrag({ ...drag, moved: true });
    } else if (drag.kind === "edge") {
      const p = toWorld(e.clientX, e.clientY);
      setDrag({ ...drag, x: p.x, y: p.y });
      const target = def.nodes.find((n) => p.x >= n.x && p.x <= n.x + NODE_W && p.y >= n.y && p.y <= n.y + NODE_H);
      setHoverTarget(target && target.id !== drag.from && target.type !== "start" ? target.id : null);
    }
  };

  const onPointerUp = () => {
    if (drag?.kind === "edge" && hoverTarget) connect(drag.from, drag.port, hoverTarget);
    setDrag(null);
    setHoverTarget(null);
  };

  const connect = (from: string, port: string, to: string) => {
    const src = byId.get(from);
    const label = src ? portsForNode(src).find((p) => p.id === port)?.label : undefined;
    // One connection per outcome port, except Fork branches which are 1:1 anyway.
    const edges = def.edges.filter((e) => !(e.from === from && e.fromPort === port));
    const edge: ProcessEdge = { id: uid("e"), from, fromPort: port, to, label };
    onChange({ ...def, edges: [...edges, edge] });
  };

  const onWheel = (e: React.WheelEvent) => {
    if (!e.ctrlKey && !e.metaKey) {
      setView((v) => ({ ...v, x: v.x - e.deltaX, y: v.y - e.deltaY }));
      return;
    }
    const r = wrapRef.current!.getBoundingClientRect();
    const mx = e.clientX - r.left;
    const my = e.clientY - r.top;
    setView((v) => {
      const k = Math.min(1.8, Math.max(0.3, v.k * (e.deltaY > 0 ? 0.9 : 1.1)));
      return { k, x: mx - ((mx - v.x) / v.k) * k, y: my - ((my - v.y) / v.k) * k };
    });
  };

  const zoom = (f: number) => setView((v) => ({ ...v, k: Math.min(1.8, Math.max(0.3, v.k * f)) }));

  const fit = () => {
    if (!def.nodes.length || !wrapRef.current) return;
    const r = wrapRef.current.getBoundingClientRect();
    const minX = Math.min(...def.nodes.map((n) => n.x));
    const minY = Math.min(...def.nodes.map((n) => n.y));
    const maxX = Math.max(...def.nodes.map((n) => n.x + NODE_W));
    const maxY = Math.max(...def.nodes.map((n) => n.y + NODE_H));
    const k = Math.min(1.2, Math.max(0.3, Math.min((r.width - 80) / (maxX - minX), (r.height - 80) / (maxY - minY))));
    setView({ k, x: (r.width - (maxX - minX) * k) / 2 - minX * k, y: 40 - minY * k });
  };

  useEffect(() => { fit(); /* first paint only */ // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const duplicate = (node: ProcessNode) => {
    if (node.type === "start") return;
    const copy: ProcessNode = { ...structuredClone(node), id: uid(node.type), x: node.x + 40, y: node.y + 40, name: `${node.name} copy` };
    if (copy.config.kind === "get_record") {
      const used = def.nodes.filter((n) => n.config.kind === "get_record").length;
      copy.config.alias = `GCR${used}`;
      copy.name = copy.config.alias;
    }
    onChange({ ...def, nodes: [...def.nodes, copy] });
    onSelect(copy.id);
  };

  const remove = (id: string) => {
    onChange({ ...def, nodes: def.nodes.filter((n) => n.id !== id), edges: def.edges.filter((e) => e.from !== id && e.to !== id) });
    onSelect(null);
  };

  return (
    <div
      ref={wrapRef}
      className="relative h-full w-full overflow-hidden bg-slate-100 select-none"
      style={{
        backgroundImage: "radial-gradient(circle, #cbd5e1 1px, transparent 1px)",
        backgroundSize: `${GRID * view.k}px ${GRID * view.k}px`,
        backgroundPosition: `${view.x}px ${view.y}px`,
      }}
      onPointerMove={onPointerMove}
      onPointerUp={onPointerUp}
      onPointerLeave={onPointerUp}
      onWheel={onWheel}
      onPointerDown={(e) => {
        if (e.target !== e.currentTarget && !(e.target as HTMLElement).dataset.canvasBg) return;
        onSelect(null);
        setSelectedEdge(null);
        setDrag({ kind: "pan", sx: e.clientX, sy: e.clientY, ox: view.x, oy: view.y });
      }}
      onDragOver={(e) => { if (e.dataTransfer.types.includes(ACTIVITY_DND_MIME)) e.preventDefault(); }}
      onDrop={(e) => {
        const type = e.dataTransfer.getData(ACTIVITY_DND_MIME) as ActivityType;
        if (!type) return;
        e.preventDefault();
        const p = toWorld(e.clientX, e.clientY);
        onDropActivity(type, snap(p.x - NODE_W / 2), snap(p.y - HEADER_H / 2));
      }}
    >
      <div
        data-canvas-bg="1"
        className="absolute left-0 top-0 origin-top-left"
        style={{ transform: `translate(${view.x}px, ${view.y}px) scale(${view.k})` }}
      >
        {/* edges */}
        <svg className="pointer-events-none absolute left-0 top-0 overflow-visible" width={1} height={1}>
          <defs>
            {Object.entries(TONE).map(([tone, color]) => (
              <marker key={tone} id={`arrow-${tone}`} viewBox="0 0 10 10" refX="8" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse">
                <path d="M 0 0 L 10 5 L 0 10 z" fill={color} />
              </marker>
            ))}
          </defs>
          {def.edges.map((edge) => {
            const a = byId.get(edge.from);
            const b = byId.get(edge.to);
            if (!a || !b) return null;
            const ports = portsForNode(a);
            const idx = Math.max(0, ports.findIndex((p) => p.id === edge.fromPort));
            const port = ports[idx];
            const tone = port?.tone ?? "neutral";
            const s = portPos(a, idx, Math.max(1, ports.length));
            const t = { x: b.x + NODE_W / 2, y: b.y - 2 };
            const d = edgePath(s.x, s.y, t.x, t.y);
            const lit = highlight.includes(edge.from) && highlight.includes(edge.to);
            const selected = selectedEdge === edge.id;
            return (
              <g key={edge.id} className="pointer-events-auto cursor-pointer" onPointerDown={(e) => { e.stopPropagation(); setSelectedEdge(edge.id); onSelect(null); }}>
                <path d={d} stroke="transparent" strokeWidth={14} fill="none" />
                <path
                  d={d}
                  fill="none"
                  stroke={selected ? "#0284c7" : TONE[tone]}
                  strokeWidth={selected || lit ? 3 : 1.75}
                  strokeDasharray={port ? undefined : "5 4"}
                  opacity={highlight.length && !lit ? 0.35 : 1}
                  markerEnd={`url(#arrow-${tone})`}
                />
                {(edge.label || port?.label) && (
                  <text x={(s.x + t.x) / 2 + 6} y={(s.y + t.y) / 2} className="fill-slate-600 text-[11px]" style={{ paintOrder: "stroke", stroke: "#f1f5f9", strokeWidth: 4 }}>
                    {port?.label ?? edge.label}
                  </text>
                )}
              </g>
            );
          })}
          {drag?.kind === "edge" && (() => {
            const a = byId.get(drag.from);
            if (!a) return null;
            const ports = portsForNode(a);
            const idx = ports.findIndex((p) => p.id === drag.port);
            const s = portPos(a, idx, ports.length);
            return <path d={edgePath(s.x, s.y, drag.x, drag.y)} stroke="#0284c7" strokeWidth={2} strokeDasharray="6 4" fill="none" />;
          })()}
        </svg>

        {/* nodes */}
        {def.nodes.map((node) => {
          const meta = ACTIVITY_META[node.type];
          const ports = portsForNode(node);
          const issue = issueByNode.get(node.id);
          const selected = selectedId === node.id;
          const lit = highlight.includes(node.id);
          return (
            <div
              key={node.id}
              className={cn(
                "absolute rounded-lg border bg-white shadow-sm transition-shadow",
                selected ? "border-sky-500 ring-2 ring-sky-200" : "border-slate-300",
                hoverTarget === node.id && "ring-2 ring-emerald-300",
                activeNodeId === node.id && "ring-4 ring-amber-300",
                highlight.length > 0 && !lit && "opacity-50",
              )}
              style={{ left: node.x, top: node.y, width: NODE_W, height: NODE_H }}
              onDoubleClick={() => onOpen(node.id)}
            >
              <div
                className={cn("flex cursor-move items-center gap-2 rounded-t-lg border-b px-2.5", meta.accent)}
                style={{ height: HEADER_H }}
                onPointerDown={(e) => {
                  e.stopPropagation();
                  setSelectedEdge(null);
                  onSelect(node.id);
                  const p = toWorld(e.clientX, e.clientY);
                  setDrag({ kind: "node", id: node.id, dx: p.x - node.x, dy: p.y - node.y, moved: false });
                }}
              >
                <ActivityIcon name={meta.icon} className="h-4 w-4 shrink-0" />
                <span className="truncate text-[13px] font-semibold">{meta.label}</span>
                {issue && (
                  <span className={cn("ml-auto h-2 w-2 shrink-0 rounded-full", issue === "error" ? "bg-rose-500" : "bg-amber-400")} title="Has validation issues" />
                )}
              </div>
              <div className="px-2.5 py-1.5" style={{ height: BODY_H }} onPointerDown={(e) => { e.stopPropagation(); onSelect(node.id); }}>
                <div className="truncate text-sm font-medium text-slate-900">{node.name}</div>
                <div className="line-clamp-2 text-[11px] leading-snug text-slate-500">{summary(node)}</div>
              </div>
              <div className="relative border-t border-slate-100" style={{ height: PORTS_H }}>
                {ports.map((p, i) => {
                  const left = (NODE_W / (ports.length + 1)) * (i + 1);
                  const wired = def.edges.some((e) => e.from === node.id && e.fromPort === p.id);
                  return (
                    <div key={p.id} className="absolute flex -translate-x-1/2 flex-col items-center" style={{ left, top: 2 }}>
                      <span className="max-w-[80px] truncate text-[10px] font-medium" style={{ color: TONE[p.tone] }}>{p.label}</span>
                      <span
                        className={cn("mt-0.5 h-3 w-3 cursor-crosshair rounded-full border-2 bg-white hover:scale-125", wired && "bg-current")}
                        style={{ borderColor: TONE[p.tone], color: TONE[p.tone] }}
                        title={`Drag to connect “${p.label}”`}
                        onPointerDown={(e) => {
                          e.stopPropagation();
                          const pos = portPos(node, i, ports.length);
                          setDrag({ kind: "edge", from: node.id, port: p.id, x: pos.x, y: pos.y });
                        }}
                      />
                    </div>
                  );
                })}
              </div>
              {node.type !== "start" && (
                <span className="absolute -top-1.5 left-1/2 h-3 w-3 -translate-x-1/2 rounded-full border-2 border-slate-400 bg-white" />
              )}
              {selected && (
                <div className="absolute -right-2 top-0 flex translate-x-full flex-col gap-1">
                  <IconBtn title="Settings" onClick={() => onOpen(node.id)}><Settings2 className="h-3.5 w-3.5" /></IconBtn>
                  {node.type !== "start" && <IconBtn title="Duplicate" onClick={() => duplicate(node)}><Copy className="h-3.5 w-3.5" /></IconBtn>}
                  {node.type !== "start" && <IconBtn title="Delete" danger onClick={() => remove(node.id)}><Trash2 className="h-3.5 w-3.5" /></IconBtn>}
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* controls */}
      <div className="absolute bottom-3 right-3 flex flex-col gap-1 rounded-lg border border-slate-200 bg-white p-1 shadow">
        <IconBtn title="Zoom in" onClick={() => zoom(1.15)}><Plus className="h-4 w-4" /></IconBtn>
        <IconBtn title="Zoom out" onClick={() => zoom(0.87)}><Minus className="h-4 w-4" /></IconBtn>
        <IconBtn title="Fit to screen" onClick={fit}><Maximize2 className="h-4 w-4" /></IconBtn>
        <IconBtn title="Tidy layout" onClick={() => { onAutoLayout(); setTimeout(fit, 0); }}><Wand2 className="h-4 w-4" /></IconBtn>
      </div>
      <div className="pointer-events-none absolute bottom-3 left-3 rounded bg-white/80 px-2 py-1 text-[11px] text-slate-500">
        {Math.round(view.k * 100)}% · drag ports to connect · double-click to configure · Del to remove
      </div>
    </div>
  );
}

function IconBtn({ children, onClick, title, danger }: { children: React.ReactNode; onClick: () => void; title: string; danger?: boolean }) {
  return (
    <button
      type="button"
      title={title}
      onPointerDown={(e) => e.stopPropagation()}
      onClick={onClick}
      className={cn("rounded-md border border-slate-200 bg-white p-1.5 shadow-sm", danger ? "text-rose-500 hover:bg-rose-50" : "text-slate-600 hover:bg-slate-50")}
    >
      {children}
    </button>
  );
}
