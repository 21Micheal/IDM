/**
 * NodeConfigModal.tsx — settings dialog for every activity type.
 * Edits a local draft and commits on Save, so Cancel is always safe.
 */

import { useState } from "react";
import { Plus, Trash2 } from "lucide-react";
import type {
  ActivityConfig, AssigneeType, HttpResponseMapping, ProcessDefinition, ProcessNode,
  RuleGroup, StepAccessRule, ValueAssignment,
} from "@/types/process";
import { ACTIVITY_META, uid } from "@/lib/process/activities";
import { emptyRuleGroup, ruleGroupHasConditions } from "@/lib/process/conditions";
import { buildRefOptions, buildTargetOptions, formFields, toToken, type ProcessFormSection } from "@/lib/process/refOptions";
import { RuleGroupEditor, type RefOption } from "./RuleGroupEditor";
import { Button, Field, ListEditor, Modal, SectionTitle, Select, TextArea, TextInput, Toggle } from "./ui";

export interface Lookup { id: string; name: string }

export interface NodeConfigModalProps {
  node: ProcessNode;
  def: ProcessDefinition;
  sections: ProcessFormSection[];
  groups?: Lookup[];
  users?: Lookup[];
  templates?: Lookup[];
  documentTypes?: Lookup[];
  connectors?: Lookup[];
  onSave: (node: ProcessNode) => void;
  onClose: () => void;
}

type Cfg<K extends ActivityConfig["kind"]> = Extract<ActivityConfig, { kind: K }>;

const DEFAULT_CONNECTORS: Lookup[] = [
  { id: "sunsystems_journal", name: "SunSystems — Journal posting" },
  { id: "sunsystems_budget", name: "SunSystems — Budget check" },
  { id: "sunsystems_po", name: "SunSystems — Purchase order" },
];

export function NodeConfigModal(props: NodeConfigModalProps) {
  const { node, def, sections, onSave, onClose } = props;
  const [draft, setDraft] = useState<ProcessNode>(() => structuredClone(node));
  const meta = ACTIVITY_META[node.type];
  const refOptions = buildRefOptions(sections, def);
  const targetOptions = buildTargetOptions(sections, def);

  const cfg = draft.config;
  const set = (patch: Partial<ActivityConfig>) =>
    setDraft((d) => ({ ...d, config: { ...d.config, ...patch } as ActivityConfig }));

  return (
    <Modal
      title={`${meta.label} settings`}
      subtitle={meta.description}
      onClose={onClose}
      width="max-w-4xl"
      footer={<>
        <Button onClick={onClose}>Cancel</Button>
        <Button variant="primary" onClick={() => onSave(draft)}>Save</Button>
      </>}
    >
      <div className="grid grid-cols-2 gap-3">
        <Field label="Name"><TextInput value={draft.name} onChange={(e) => setDraft({ ...draft, name: e.target.value })} /></Field>
        <Field label="Description"><TextInput value={draft.description ?? ""} onChange={(e) => setDraft({ ...draft, description: e.target.value })} /></Field>
      </div>

      {cfg.kind === "start" && <StartPanel cfg={cfg} set={set} refOptions={refOptions} />}
      {cfg.kind === "assignment" && <AssignmentPanel cfg={cfg} set={set} refOptions={refOptions} sections={sections} def={def} groups={props.groups ?? []} users={props.users ?? []} />}
      {cfg.kind === "notification" && <NotificationPanel cfg={cfg} set={set} refOptions={refOptions} sections={sections} groups={props.groups ?? []} users={props.users ?? []} />}
      {cfg.kind === "set_value" && <SetValuePanel cfg={cfg} set={set} refOptions={refOptions} targets={targetOptions} />}
      {cfg.kind === "calculate" && (
        <>
          <SectionTitle>Calculation</SectionTitle>
          <div className="grid grid-cols-3 gap-3">
            <Field label="Store result in"><TargetSelect value={cfg.target} options={targetOptions} onChange={(v) => set({ target: v })} /></Field>
            <Field label="Decimals"><TextInput type="number" value={cfg.decimals ?? 2} onChange={(e) => set({ decimals: Number(e.target.value) })} /></Field>
          </div>
          <Field className="mt-3" label="Expression" hint="Same grammar as your calculated fields, e.g. {{field.amount}} * 0.16">
            <TextArea value={cfg.expression} onChange={(e) => set({ expression: e.target.value })} />
          </Field>
          <TokenBar options={refOptions} onInsert={(t) => set({ expression: `${cfg.expression}${t}` })} />
        </>
      )}
      {cfg.kind === "if_else" && (
        <>
          <SectionTitle>Condition</SectionTitle>
          <RuleGroupEditor group={cfg.rules} refOptions={refOptions} onChange={(rules) => set({ rules })} />
          <div className="mt-3 grid grid-cols-2 gap-3">
            <Field label="True outcome label"><TextInput value={cfg.trueLabel ?? ""} onChange={(e) => set({ trueLabel: e.target.value })} /></Field>
            <Field label="False outcome label"><TextInput value={cfg.falseLabel ?? ""} onChange={(e) => set({ falseLabel: e.target.value })} /></Field>
          </div>
        </>
      )}
      {cfg.kind === "switch" && <SwitchPanel cfg={cfg} set={set} refOptions={refOptions} />}
      {cfg.kind === "get_record" && <GetRecordPanel cfg={cfg} set={set} refOptions={refOptions} sections={sections} documentTypes={props.documentTypes ?? []} />}
      {cfg.kind === "fork" && (
        <>
          <SectionTitle right={<Button variant="ghost" onClick={() => set({ branches: [...cfg.branches, { id: uid("br"), label: `Branch ${cfg.branches.length + 1}` }] })}><Plus className="h-3.5 w-3.5" /> Branch</Button>}>Parallel branches</SectionTitle>
          {cfg.branches.map((b, i) => (
            <div key={b.id} className="mb-2 flex gap-2">
              <TextInput value={b.label} onChange={(e) => set({ branches: cfg.branches.map((x, j) => (j === i ? { ...x, label: e.target.value } : x)) })} />
              <Button variant="danger" disabled={cfg.branches.length <= 2} onClick={() => set({ branches: cfg.branches.filter((_, j) => j !== i) })}><Trash2 className="h-3.5 w-3.5" /></Button>
            </div>
          ))}
          <p className="text-[11px] text-slate-500">Each branch becomes an outcome port. Close them with a Join.</p>
        </>
      )}
      {cfg.kind === "join" && (
        <>
          <SectionTitle>Join behaviour</SectionTitle>
          <Select value={cfg.mode} onChange={(e) => set({ mode: e.target.value as "all" | "any" })}>
            <option value="all">Wait for every incoming branch</option>
            <option value="any">Continue on the first branch to arrive</option>
          </Select>
        </>
      )}
      {(cfg.kind === "http_request" || cfg.kind === "http_background") && <HttpPanel cfg={cfg} set={set} refOptions={refOptions} targets={targetOptions} />}
      {cfg.kind === "http_receive" && (
        <>
          <SectionTitle>Callback endpoint</SectionTitle>
          <div className="grid grid-cols-2 gap-3">
            <Field label="Token" hint={`POST /api/public/process/${cfg.token}/<instanceId>`}><TextInput value={cfg.token} onChange={(e) => set({ token: e.target.value })} /></Field>
            <Field label="Secret header name" hint="Value is stored server-side, not in the template"><TextInput value={cfg.secretHeader ?? ""} onChange={(e) => set({ secretHeader: e.target.value })} /></Field>
            <Field label="Timeout (hours)"><TextInput type="number" value={cfg.timeoutHours ?? 72} onChange={(e) => set({ timeoutHours: Number(e.target.value) })} /></Field>
          </div>
          <MappingEditor title="Map callback payload" rows={cfg.mapping ?? []} targets={targetOptions} onChange={(mapping) => set({ mapping })} />
        </>
      )}
      {cfg.kind === "http_response" && (
        <>
          <SectionTitle>Response</SectionTitle>
          <div className="grid grid-cols-2 gap-3">
            <Field label="Status code"><TextInput type="number" value={cfg.status} onChange={(e) => set({ status: Number(e.target.value) })} /></Field>
            <Field label="Content type"><TextInput value={cfg.contentType ?? ""} onChange={(e) => set({ contentType: e.target.value })} /></Field>
          </div>
          <Field className="mt-3" label="Body"><TextArea value={cfg.body ?? ""} onChange={(e) => set({ body: e.target.value })} /></Field>
        </>
      )}
      {cfg.kind === "data_connector" && (
        <>
          <SectionTitle>Connector</SectionTitle>
          <div className="grid grid-cols-3 gap-3">
            <Field label="Connector">
              <Select value={cfg.connector} onChange={(e) => set({ connector: e.target.value })}>
                {(props.connectors?.length ? props.connectors : DEFAULT_CONNECTORS).map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
              </Select>
            </Field>
            <Field label="Label"><TextInput value={cfg.label ?? ""} onChange={(e) => set({ label: e.target.value })} /></Field>
            <Field label="Journal stage" hint="Matches SunSystems journal stages"><TextInput type="number" value={cfg.stage ?? ""} onChange={(e) => set({ stage: e.target.value ? Number(e.target.value) : undefined })} /></Field>
          </div>
          <KeyValueEditor title="Parameters" rows={cfg.parameters ?? []} onChange={(parameters) => set({ parameters })} />
          <MappingEditor title="Map connector response" rows={cfg.mapping ?? []} targets={targetOptions} onChange={(mapping) => set({ mapping })} />
          <OptionalRule title="Run only when" value={cfg.runWhen} refOptions={refOptions} onChange={(runWhen) => set({ runWhen })} />
          <div className="mt-3"><Toggle checked={!!cfg.continueOnError} onChange={(v) => set({ continueOnError: v })} label="Route failures to the Error outcome" hint="Otherwise the instance stops with an error" /></div>
        </>
      )}
      {cfg.kind === "delay" && (
        <>
          <SectionTitle>Wait</SectionTitle>
          <div className="grid grid-cols-3 gap-3">
            <Field label="Mode">
              <Select value={cfg.mode} onChange={(e) => set({ mode: e.target.value as "duration" | "until_date" })}>
                <option value="duration">For a duration</option>
                <option value="until_date">Until a date</option>
              </Select>
            </Field>
            {cfg.mode === "duration"
              ? <Field label="Hours"><TextInput type="number" value={cfg.hours ?? 0} onChange={(e) => set({ hours: Number(e.target.value) })} /></Field>
              : <Field label="Date reference"><RefSelect value={cfg.untilRef ?? ""} options={refOptions} onChange={(v) => set({ untilRef: v })} /></Field>}
          </div>
          <div className="mt-3"><Toggle checked={!!cfg.workingHours} onChange={(v) => set({ workingHours: v })} label="Count working hours only" /></div>
        </>
      )}
      {(cfg.kind === "create_document" || cfg.kind === "sub_process") && (
        <>
          <SectionTitle>Template</SectionTitle>
          <div className="grid grid-cols-2 gap-3">
            <Field label="Template">
              <LookupSelect value={cfg.templateId} items={props.templates ?? []} onChange={(v) => set({ templateId: v })} />
            </Field>
            {cfg.kind === "create_document" && (
              <Field label="Title"><TextInput value={cfg.titleExpression ?? ""} placeholder="PO for {{field.reference}}" onChange={(e) => set({ titleExpression: e.target.value })} /></Field>
            )}
          </div>
          <PairEditor title="Copy values" rows={cfg.mapping ?? []} fromOptions={refOptions} onChange={(mapping) => set({ mapping })} />
          <div className="mt-3">
            {cfg.kind === "create_document"
              ? <Toggle checked={!!cfg.startProcess} onChange={(v) => set({ startProcess: v })} label="Submit the new document immediately" />
              : <Toggle checked={cfg.waitForCompletion} onChange={(v) => set({ waitForCompletion: v })} label="Wait for the sub-process to finish" />}
          </div>
        </>
      )}
      {cfg.kind === "script" && (
        <>
          <SectionTitle>Assignments (one per line)</SectionTitle>
          <TextArea className="min-h-[180px]" value={cfg.body} placeholder={"var:vat = {{field.amount}} * 0.16\nfield:total = {{field.amount}} + {{var.vat}}"} onChange={(e) => set({ body: e.target.value })} />
          <TokenBar options={refOptions} onInsert={(t) => set({ body: `${cfg.body}${t}` })} />
        </>
      )}
      {cfg.kind === "completed" && (
        <>
          <SectionTitle>Completion</SectionTitle>
          <div className="grid grid-cols-2 gap-3">
            <Field label="Final status"><TextInput value={cfg.finalStatus} onChange={(e) => set({ finalStatus: e.target.value })} /></Field>
            <Field label="Message"><TextInput value={cfg.message ?? ""} onChange={(e) => set({ message: e.target.value })} /></Field>
          </div>
          <div className="mt-3"><Toggle checked={!!cfg.lockDocument} onChange={(v) => set({ lockDocument: v })} label="Lock the document" /></div>
        </>
      )}
      {cfg.kind === "terminate" && (
        <>
          <SectionTitle>Termination</SectionTitle>
          <div className="grid grid-cols-2 gap-3">
            <Field label="Final status"><TextInput value={cfg.finalStatus} onChange={(e) => set({ finalStatus: e.target.value })} /></Field>
            <Field label="Reason"><TextInput value={cfg.reason ?? ""} onChange={(e) => set({ reason: e.target.value })} /></Field>
          </div>
        </>
      )}
    </Modal>
  );
}

/* ── panels ────────────────────────────────────────────────────────────── */

type SetFn = (patch: Partial<ActivityConfig>) => void;

function StartPanel({ cfg, set, refOptions }: { cfg: Cfg<"start">; set: SetFn; refOptions: RefOption[] }) {
  return (
    <>
      <SectionTitle>Submission</SectionTitle>
      <Field label="Status on submit"><TextInput value={cfg.statusLabel} onChange={(e) => set({ statusLabel: e.target.value })} /></Field>
      <div className="mt-3"><Toggle checked={!!cfg.allowDraft} onChange={(v) => set({ allowDraft: v })} label="Allow saving as draft" /></div>
      <OptionalRule title="Only allow submission when" value={cfg.preconditions} refOptions={refOptions} onChange={(preconditions) => set({ preconditions })} />
    </>
  );
}

const ASSIGNEE_TYPES: { id: AssigneeType; label: string }[] = [
  { id: "group_any", label: "Anyone in a group" },
  { id: "group_all", label: "Everyone in a group" },
  { id: "group_specific", label: "A specific user in a group" },
  { id: "user", label: "A named user" },
  { id: "initiator", label: "The initiator" },
  { id: "manager", label: "The initiator's manager" },
  { id: "field_user", label: "User picked in a form field" },
  { id: "variable", label: "User held in a variable" },
];

function AssignmentPanel({
  cfg, set, refOptions, sections, def, groups, users,
}: { cfg: Cfg<"assignment">; set: SetFn; refOptions: RefOption[]; sections: ProcessFormSection[]; def: ProcessDefinition; groups: Lookup[]; users: Lookup[] }) {
  const needsGroup = cfg.assigneeType.startsWith("group_");
  const needsUser = cfg.assigneeType === "user" || cfg.assigneeType === "group_specific";
  const esc = cfg.escalation ?? { enabled: false, afterHours: 24, action: "notify" as const };

  return (
    <>
      <SectionTitle>Assignee</SectionTitle>
      <div className="grid grid-cols-2 gap-3">
        <Field label="Status while waiting"><TextInput value={cfg.statusLabel} onChange={(e) => set({ statusLabel: e.target.value })} /></Field>
        <Field label="Assign to">
          <Select value={cfg.assigneeType} onChange={(e) => set({ assigneeType: e.target.value as AssigneeType })}>
            {ASSIGNEE_TYPES.map((t) => <option key={t.id} value={t.id}>{t.label}</option>)}
          </Select>
        </Field>
        {needsGroup && (
          <Field label="Group">
            <LookupSelect value={cfg.assigneeGroup ?? ""} items={groups} onChange={(v) => set({ assigneeGroup: v || null, assigneeGroupName: groups.find((g) => g.id === v)?.name })} />
          </Field>
        )}
        {needsUser && (
          <Field label="User">
            <LookupSelect value={cfg.assigneeUser ?? ""} items={users} onChange={(v) => set({ assigneeUser: v || null, assigneeUserName: users.find((u) => u.id === v)?.name })} />
          </Field>
        )}
        {cfg.assigneeType === "field_user" && (
          <Field label="Form field"><RefSelect value={cfg.assigneeRef ?? ""} options={refOptions.filter((o) => o.value.startsWith("field."))} onChange={(v) => set({ assigneeRef: v })} /></Field>
        )}
        {cfg.assigneeType === "variable" && (
          <Field label="Variable"><RefSelect value={cfg.assigneeRef ?? ""} options={refOptions.filter((o) => o.value.startsWith("var."))} onChange={(v) => set({ assigneeRef: v })} /></Field>
        )}
        <Field label="SLA (hours)"><TextInput type="number" value={cfg.slaHours} onChange={(e) => set({ slaHours: Number(e.target.value) })} /></Field>
      </div>

      <SectionTitle>Allowed actions</SectionTitle>
      <div className="grid grid-cols-2 gap-2">
        <Toggle checked={cfg.allowApprove} onChange={(v) => set({ allowApprove: v })} label="Approve" />
        <Toggle checked={cfg.allowReject} onChange={(v) => set({ allowReject: v })} label="Reject" />
        <Toggle checked={cfg.allowReturn} onChange={(v) => set({ allowReturn: v })} label="Return for changes" hint="Adds a Returned outcome" />
        <Toggle checked={cfg.allowResubmit} onChange={(v) => set({ allowResubmit: v })} label="Allow resubmission" />
        <Toggle checked={!!cfg.allowDelegate} onChange={(v) => set({ allowDelegate: v })} label="Allow delegation" />
        <Toggle checked={cfg.requiresSignature} onChange={(v) => set({ requiresSignature: v })} label="Require signature" />
        <Toggle checked={!!cfg.requireComment} onChange={(v) => set({ requireComment: v })} label="Require a comment" />
      </div>

      <AccessEditor sections={sections} value={cfg.access ?? []} onChange={(access) => set({ access })} />

      <OptionalRule title="Skip this step when" value={cfg.skipWhen} refOptions={refOptions} onChange={(skipWhen) => set({ skipWhen })} />
      <OptionalRule title="Auto-approve when" value={cfg.autoApproveWhen} refOptions={refOptions} onChange={(autoApproveWhen) => set({ autoApproveWhen })} />

      <SectionTitle>Escalation</SectionTitle>
      <Toggle checked={esc.enabled} onChange={(v) => set({ escalation: { ...esc, enabled: v } })} label="Escalate when the SLA is missed" hint="Adds an Escalated outcome" />
      {esc.enabled && (
        <div className="mt-2 grid grid-cols-3 gap-3">
          <Field label="After (hours)"><TextInput type="number" value={esc.afterHours} onChange={(e) => set({ escalation: { ...esc, afterHours: Number(e.target.value) } })} /></Field>
          <Field label="Action">
            <Select value={esc.action} onChange={(e) => set({ escalation: { ...esc, action: e.target.value as typeof esc.action } })}>
              <option value="notify">Notify only</option>
              <option value="reassign">Reassign</option>
              <option value="auto_approve">Auto-approve</option>
              <option value="auto_reject">Auto-reject</option>
            </Select>
          </Field>
          {(esc.action === "notify" || esc.action === "reassign") && (
            <Field label={esc.action === "notify" ? "Notify group" : "Reassign to group"}>
              <LookupSelect
                value={(esc.action === "notify" ? esc.notifyGroup : esc.reassignGroup) ?? ""}
                items={groups}
                onChange={(v) => set({ escalation: { ...esc, [esc.action === "notify" ? "notifyGroup" : "reassignGroup"]: v || null } })}
              />
            </Field>
          )}
        </div>
      )}

      <SectionTitle>Instructions & approver email</SectionTitle>
      <Field label="Instructions shown to the approver"><TextArea value={cfg.instructions ?? ""} onChange={(e) => set({ instructions: e.target.value })} /></Field>
      <div className="mt-3 grid grid-cols-2 gap-3">
        <Field label="Email subject"><TextInput value={cfg.approverEmailSubject ?? ""} onChange={(e) => set({ approverEmailSubject: e.target.value })} /></Field>
      </div>
      <Field className="mt-3" label="Email body"><TextArea value={cfg.approverEmailBody ?? ""} onChange={(e) => set({ approverEmailBody: e.target.value })} /></Field>
      <TokenBar options={refOptions} onInsert={(t) => set({ approverEmailBody: `${cfg.approverEmailBody ?? ""}${t}` })} />
      {def.variables.length === 0 && null}
    </>
  );
}

/** Per-step form access: the core reason for merging form + workflow. */
function AccessEditor({ sections, value, onChange }: { sections: ProcessFormSection[]; value: StepAccessRule[]; onChange: (v: StepAccessRule[]) => void }) {
  const modeOf = (target: string) => value.find((r) => r.target === target)?.mode ?? "";
  const setMode = (target: string, mode: string) => {
    const rest = value.filter((r) => r.target !== target);
    onChange(mode ? [...rest, { target, mode: mode as StepAccessRule["mode"] }] : rest);
  };
  const [expanded, setExpanded] = useState<string | null>(null);
  return (
    <>
      <SectionTitle>Form access at this step</SectionTitle>
      <p className="mb-2 text-[11px] text-slate-500">Leave as “Default” to use the section's own rules from the Form tab.</p>
      <div className="divide-y divide-slate-100 rounded-md border border-slate-200">
        {sections.map((s) => (
          <div key={s.id} className="px-3 py-2">
            <div className="flex items-center gap-2">
              <button type="button" className="flex-1 text-left text-sm font-medium text-slate-800" onClick={() => setExpanded(expanded === s.id ? null : s.id)}>
                {s.title} <span className="text-[11px] font-normal text-slate-400">({s.fields.length} fields)</span>
              </button>
              <AccessSelect value={modeOf(s.id)} onChange={(m) => setMode(s.id, m)} />
            </div>
            {expanded === s.id && (
              <div className="mt-2 space-y-1 pl-3">
                {formFields([s]).map((f) => (
                  <div key={f.key} className="flex items-center gap-2 text-[13px] text-slate-600">
                    <span className="flex-1 truncate">{f.label}</span>
                    <AccessSelect value={modeOf(`field:${f.key}`)} onChange={(m) => setMode(`field:${f.key}`, m)} />
                  </div>
                ))}
              </div>
            )}
          </div>
        ))}
        {!sections.length && <div className="px-3 py-2 text-xs text-slate-400">Add sections in the Form tab first.</div>}
      </div>
    </>
  );
}

function AccessSelect({ value, onChange }: { value: string; onChange: (v: string) => void }) {
  return (
    <Select className="w-32 py-1 text-xs" value={value} onChange={(e) => onChange(e.target.value)}>
      <option value="">Default</option>
      <option value="editable">Editable</option>
      <option value="readonly">Read-only</option>
      <option value="hidden">Hidden</option>
    </Select>
  );
}

function NotificationPanel({
  cfg, set, refOptions, groups, users,
}: { cfg: Cfg<"notification">; set: SetFn; refOptions: RefOption[]; sections: ProcessFormSection[]; groups: Lookup[]; users: Lookup[] }) {
  const nameOf = (items: Lookup[], id: string) => items.find((x) => x.id === id)?.name ?? id;
  return (
    <>
      <SectionTitle>Recipients</SectionTitle>
      <div className="grid grid-cols-2 gap-3">
        <Field label="Channel">
          <Select value={cfg.channel} onChange={(e) => set({ channel: e.target.value as typeof cfg.channel })}>
            <option value="email">Email</option>
            <option value="in_app">In-app</option>
            <option value="both">Email and in-app</option>
          </Select>
        </Field>
        <div className="pt-5"><Toggle checked={!!cfg.toInitiator} onChange={(v) => set({ toInitiator: v })} label="Send to the initiator" /></div>
        <Field label="Groups">
          <MultiLookup items={groups} values={cfg.toGroups ?? []} onChange={(toGroups) => set({ toGroups })} nameOf={(id) => nameOf(groups, id)} />
        </Field>
        <Field label="Users">
          <MultiLookup items={users} values={cfg.toUsers ?? []} onChange={(toUsers) => set({ toUsers })} nameOf={(id) => nameOf(users, id)} />
        </Field>
        <Field label="Email addresses"><ListEditor values={cfg.toEmails ?? []} onChange={(toEmails) => set({ toEmails })} placeholder="name@company.com" /></Field>
        <Field label="Email/user from form fields">
          <MultiLookup
            items={refOptions.filter((o) => o.value.startsWith("field.")).map((o) => ({ id: o.value.slice(6), name: o.label }))}
            values={cfg.toFieldKeys ?? []}
            onChange={(toFieldKeys) => set({ toFieldKeys })}
            nameOf={(id) => id}
          />
        </Field>
      </div>
      <SectionTitle>Message</SectionTitle>
      <Field label="Subject"><TextInput value={cfg.subject} onChange={(e) => set({ subject: e.target.value })} /></Field>
      <Field className="mt-3" label="Body"><TextArea className="min-h-[140px]" value={cfg.body} onChange={(e) => set({ body: e.target.value })} /></Field>
      <TokenBar options={refOptions} onInsert={(t) => set({ body: `${cfg.body}${t}` })} />
      <div className="mt-3 grid grid-cols-2 gap-2">
        <Toggle checked={!!cfg.includeItemsTable} onChange={(v) => set({ includeItemsTable: v })} label="Include items table" />
        <Toggle checked={!!cfg.attachDocument} onChange={(v) => set({ attachDocument: v })} label="Attach the document PDF" />
      </div>
      <OptionalRule title="Send only when" value={cfg.sendWhen} refOptions={refOptions} onChange={(sendWhen) => set({ sendWhen })} />
    </>
  );
}

function SetValuePanel({ cfg, set, refOptions, targets }: { cfg: Cfg<"set_value">; set: SetFn; refOptions: RefOption[]; targets: RefOption[] }) {
  const update = (i: number, patch: Partial<ValueAssignment>) =>
    set({ assignments: cfg.assignments.map((a, j) => (j === i ? { ...a, ...patch } : a)) });
  return (
    <>
      <SectionTitle right={<Button variant="ghost" onClick={() => set({ assignments: [...cfg.assignments, { id: uid("asg"), target: "", mode: "constant", value: "" }] })}><Plus className="h-3.5 w-3.5" /> Assignment</Button>}>Assignments</SectionTitle>
      {cfg.assignments.map((a, i) => (
        <div key={a.id} className="mb-2 rounded-md border border-slate-200 p-2">
          <div className="flex flex-wrap items-center gap-2">
            <TargetSelect className="w-56" value={a.target} options={targets} onChange={(v) => update(i, { target: v })} />
            <span className="text-slate-400">=</span>
            <Select className="w-36" value={a.mode} onChange={(e) => update(i, { mode: e.target.value as ValueAssignment["mode"] })}>
              <option value="constant">Constant</option>
              <option value="expression">Expression</option>
              <option value="formula">Formula</option>
            </Select>
            <TextInput className="flex-1" value={a.value} placeholder={a.mode === "constant" ? "Value" : "{{field.amount}} * 0.16"} onChange={(e) => update(i, { value: e.target.value })} />
            <Button variant="danger" onClick={() => set({ assignments: cfg.assignments.filter((_, j) => j !== i) })}><Trash2 className="h-3.5 w-3.5" /></Button>
          </div>
          <OptionalRule title="Only when" value={a.when} refOptions={refOptions} onChange={(when) => update(i, { when })} compact />
        </div>
      ))}
      {!cfg.assignments.length && <p className="text-xs text-slate-400">No assignments yet.</p>}
    </>
  );
}

function SwitchPanel({ cfg, set, refOptions }: { cfg: Cfg<"switch">; set: SetFn; refOptions: RefOption[] }) {
  return (
    <>
      <SectionTitle right={<Button variant="ghost" onClick={() => set({ cases: [...cfg.cases, { id: uid("case"), label: `Case ${cfg.cases.length + 1}`, rules: emptyRuleGroup() }] })}><Plus className="h-3.5 w-3.5" /> Case</Button>}>Cases (first match wins)</SectionTitle>
      {cfg.cases.map((c, i) => (
        <div key={c.id} className="mb-3 rounded-md border border-slate-200 p-2">
          <div className="mb-2 flex gap-2">
            <TextInput value={c.label} onChange={(e) => set({ cases: cfg.cases.map((x, j) => (j === i ? { ...x, label: e.target.value } : x)) })} />
            <Button disabled={i === 0} onClick={() => { const n = [...cfg.cases]; [n[i - 1], n[i]] = [n[i], n[i - 1]]; set({ cases: n }); }}>↑</Button>
            <Button variant="danger" onClick={() => set({ cases: cfg.cases.filter((_, j) => j !== i) })}><Trash2 className="h-3.5 w-3.5" /></Button>
          </div>
          <RuleGroupEditor group={c.rules} refOptions={refOptions} onChange={(rules) => set({ cases: cfg.cases.map((x, j) => (j === i ? { ...x, rules } : x)) })} />
        </div>
      ))}
      <Toggle checked={!!cfg.hasDefault} onChange={(v) => set({ hasDefault: v })} label="Add a Default outcome when nothing matches" />
      <p className="mt-2 text-[11px] text-slate-500">Typical use: amount bands — under 50,000 · 50,000–500,000 · over 500,000 — each routed to a different approval chain.</p>
    </>
  );
}

function GetRecordPanel({
  cfg, set, refOptions, sections, documentTypes,
}: { cfg: Cfg<"get_record">; set: SetFn; refOptions: RefOption[]; sections: ProcessFormSection[]; documentTypes: Lookup[] }) {
  return (
    <>
      <SectionTitle>Record</SectionTitle>
      <div className="grid grid-cols-3 gap-3">
        <Field label="Alias" hint="Referenced as {{alias.field}}"><TextInput value={cfg.alias} onChange={(e) => set({ alias: e.target.value.replace(/\s/g, "") })} /></Field>
        <Field label="Source">
          <Select value={cfg.source} onChange={(e) => set({ source: e.target.value as typeof cfg.source })}>
            <option value="current">Current record</option>
            <option value="related">Related record</option>
            <option value="lookup">Lookup by rule</option>
            <option value="initiator">Initiator profile</option>
            <option value="api">External API</option>
          </Select>
        </Field>
        {(cfg.source === "related" || cfg.source === "lookup") && (
          <Field label="Document type"><LookupSelect value={cfg.documentTypeId ?? ""} items={documentTypes} onChange={(v) => set({ documentTypeId: v || null })} /></Field>
        )}
      </div>
      <Field className="mt-3" label="Fields to load">
        <MultiLookup
          items={formFields(sections).map((f) => ({ id: f.key, name: f.label }))}
          values={cfg.fields}
          onChange={(fields) => set({ fields })}
          nameOf={(id) => id}
          allowFree
        />
      </Field>
      {cfg.source === "lookup" && (
        <>
          <SectionTitle>Match rule</SectionTitle>
          <RuleGroupEditor group={cfg.match ?? emptyRuleGroup()} refOptions={refOptions} onChange={(match) => set({ match })} />
        </>
      )}
      <div className="mt-3"><Toggle checked={!!cfg.requireMatch} onChange={(v) => set({ requireMatch: v })} label="Fail when no record is found" /></div>
    </>
  );
}

function HttpPanel({ cfg, set, refOptions, targets }: { cfg: Cfg<"http_request"> | Cfg<"http_background">; set: SetFn; refOptions: RefOption[]; targets: RefOption[] }) {
  const auth = cfg.auth ?? { type: "none" as const };
  return (
    <>
      <SectionTitle>Request</SectionTitle>
      <div className="flex gap-2">
        <Select className="w-28" value={cfg.method} onChange={(e) => set({ method: e.target.value as typeof cfg.method })}>
          {["GET", "POST", "PUT", "PATCH", "DELETE"].map((m) => <option key={m}>{m}</option>)}
        </Select>
        <TextInput value={cfg.url} placeholder="https://api.example.com/orders/{{field.reference}}" onChange={(e) => set({ url: e.target.value })} />
      </div>
      <div className="mt-3 grid grid-cols-4 gap-3">
        <Field label="Auth">
          <Select value={auth.type} onChange={(e) => set({ auth: { ...auth, type: e.target.value as typeof auth.type } })}>
            <option value="none">None</option><option value="basic">Basic</option><option value="bearer">Bearer</option><option value="api_key">API key</option>
          </Select>
        </Field>
        {auth.type !== "none" && <Field label="Credential name" hint="Stored server-side"><TextInput value={auth.ref ?? ""} onChange={(e) => set({ auth: { ...auth, ref: e.target.value } })} /></Field>}
        <Field label="Timeout (s)"><TextInput type="number" value={cfg.timeoutSeconds ?? 30} onChange={(e) => set({ timeoutSeconds: Number(e.target.value) })} /></Field>
        <Field label="Retries"><TextInput type="number" value={cfg.retries ?? 0} onChange={(e) => set({ retries: Number(e.target.value) })} /></Field>
      </div>
      <KeyValueEditor title="Headers" rows={cfg.headers} onChange={(headers) => set({ headers })} />
      {cfg.method !== "GET" && (
        <>
          <Field className="mt-3" label="Body (JSON with tokens)"><TextArea className="min-h-[120px]" value={cfg.body ?? ""} onChange={(e) => set({ body: e.target.value })} /></Field>
          <TokenBar options={refOptions} onInsert={(t) => set({ body: `${cfg.body ?? ""}${t}` })} />
        </>
      )}
      <MappingEditor title="Map response" rows={cfg.responseMapping ?? []} targets={targets} onChange={(responseMapping) => set({ responseMapping })} />
      <div className="mt-3"><Toggle checked={!!cfg.continueOnError} onChange={(v) => set({ continueOnError: v })} label="Route failures to the Error outcome" /></div>
    </>
  );
}

/* ── shared bits ───────────────────────────────────────────────────────── */

function OptionalRule({
  title, value, onChange, refOptions, compact,
}: { title: string; value?: RuleGroup | null; onChange: (g: RuleGroup | null) => void; refOptions: RefOption[]; compact?: boolean }) {
  const on = !!value;
  return (
    <div className={compact ? "mt-2" : "mt-4"}>
      <label className="flex items-center gap-2 text-sm text-slate-700">
        <input type="checkbox" checked={on} onChange={(e) => onChange(e.target.checked ? emptyRuleGroup() : null)} />
        {title}
        {on && !ruleGroupHasConditions(value) && <span className="text-[11px] text-amber-600">(add a condition)</span>}
      </label>
      {on && value && <div className="mt-2"><RuleGroupEditor group={value} refOptions={refOptions} onChange={onChange} /></div>}
    </div>
  );
}

function groupedOptions(options: RefOption[]) {
  const g: Record<string, RefOption[]> = {};
  for (const o of options) (g[o.group] ||= []).push(o);
  return Object.entries(g).map(([name, opts]) => (
    <optgroup key={name} label={name}>{opts.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}</optgroup>
  ));
}

function RefSelect({ value, options, onChange, className }: { value: string; options: RefOption[]; onChange: (v: string) => void; className?: string }) {
  return <Select className={className} value={value} onChange={(e) => onChange(e.target.value)}><option value="">Select…</option>{groupedOptions(options)}</Select>;
}
const TargetSelect = RefSelect;

function LookupSelect({ value, items, onChange }: { value: string; items: Lookup[]; onChange: (v: string) => void }) {
  if (!items.length) return <TextInput value={value} placeholder="ID" onChange={(e) => onChange(e.target.value)} />;
  return (
    <Select value={value} onChange={(e) => onChange(e.target.value)}>
      <option value="">Select…</option>
      {items.map((i) => <option key={i.id} value={i.id}>{i.name}</option>)}
    </Select>
  );
}

function MultiLookup({
  items, values, onChange, nameOf, allowFree,
}: { items: Lookup[]; values: string[]; onChange: (v: string[]) => void; nameOf: (id: string) => string; allowFree?: boolean }) {
  if (!items.length || allowFree) {
    return (
      <div>
        {items.length > 0 && (
          <Select className="mb-1" value="" onChange={(e) => e.target.value && !values.includes(e.target.value) && onChange([...values, e.target.value])}>
            <option value="">Add…</option>
            {items.filter((i) => !values.includes(i.id)).map((i) => <option key={i.id} value={i.id}>{i.name}</option>)}
          </Select>
        )}
        <ListEditor values={values} onChange={onChange} />
      </div>
    );
  }
  return (
    <div>
      <Select value="" onChange={(e) => e.target.value && onChange([...values, e.target.value])}>
        <option value="">Add…</option>
        {items.filter((i) => !values.includes(i.id)).map((i) => <option key={i.id} value={i.id}>{i.name}</option>)}
      </Select>
      <div className="mt-1 flex flex-wrap gap-1">
        {values.map((v) => (
          <span key={v} className="inline-flex items-center gap-1 rounded-full bg-slate-100 px-2 py-0.5 text-xs">
            {nameOf(v)}
            <button type="button" className="text-slate-400 hover:text-rose-500" onClick={() => onChange(values.filter((x) => x !== v))}>×</button>
          </span>
        ))}
      </div>
    </div>
  );
}

function TokenBar({ options, onInsert }: { options: RefOption[]; onInsert: (token: string) => void }) {
  return (
    <div className="mt-1 flex items-center gap-2">
      <span className="text-[11px] text-slate-400">Insert:</span>
      <Select className="w-64 py-1 text-xs" value="" onChange={(e) => e.target.value && onInsert(toToken(e.target.value))}>
        <option value="">Field, variable or context…</option>
        {groupedOptions(options)}
      </Select>
    </div>
  );
}

function KeyValueEditor({
  title, rows, onChange,
}: { title: string; rows: { id: string; name: string; value: string }[]; onChange: (r: { id: string; name: string; value: string }[]) => void }) {
  return (
    <>
      <SectionTitle right={<Button variant="ghost" onClick={() => onChange([...rows, { id: uid("kv"), name: "", value: "" }])}><Plus className="h-3.5 w-3.5" /> Add</Button>}>{title}</SectionTitle>
      {rows.map((r, i) => (
        <div key={r.id} className="mb-1 flex gap-2">
          <TextInput placeholder="Name" value={r.name} onChange={(e) => onChange(rows.map((x, j) => (j === i ? { ...x, name: e.target.value } : x)))} />
          <TextInput placeholder="Value or {{token}}" value={r.value} onChange={(e) => onChange(rows.map((x, j) => (j === i ? { ...x, value: e.target.value } : x)))} />
          <Button variant="danger" onClick={() => onChange(rows.filter((_, j) => j !== i))}><Trash2 className="h-3.5 w-3.5" /></Button>
        </div>
      ))}
    </>
  );
}

function MappingEditor({
  title, rows, targets, onChange,
}: { title: string; rows: HttpResponseMapping[]; targets: RefOption[]; onChange: (r: HttpResponseMapping[]) => void }) {
  return (
    <>
      <SectionTitle right={<Button variant="ghost" onClick={() => onChange([...rows, { id: uid("map"), path: "", target: "" }])}><Plus className="h-3.5 w-3.5" /> Add</Button>}>{title}</SectionTitle>
      {rows.map((r, i) => (
        <div key={r.id} className="mb-1 flex items-center gap-2">
          <TextInput placeholder="data.id" value={r.path} onChange={(e) => onChange(rows.map((x, j) => (j === i ? { ...x, path: e.target.value } : x)))} />
          <span className="text-slate-400">→</span>
          <TargetSelect value={r.target} options={targets} onChange={(v) => onChange(rows.map((x, j) => (j === i ? { ...x, target: v } : x)))} />
          <Button variant="danger" onClick={() => onChange(rows.filter((_, j) => j !== i))}><Trash2 className="h-3.5 w-3.5" /></Button>
        </div>
      ))}
    </>
  );
}

function PairEditor({
  title, rows, fromOptions, onChange,
}: { title: string; rows: { id: string; from: string; to: string }[]; fromOptions: RefOption[]; onChange: (r: { id: string; from: string; to: string }[]) => void }) {
  return (
    <>
      <SectionTitle right={<Button variant="ghost" onClick={() => onChange([...rows, { id: uid("map"), from: "", to: "" }])}><Plus className="h-3.5 w-3.5" /> Add</Button>}>{title}</SectionTitle>
      {rows.map((r, i) => (
        <div key={r.id} className="mb-1 flex items-center gap-2">
          <RefSelect value={r.from} options={fromOptions} onChange={(v) => onChange(rows.map((x, j) => (j === i ? { ...x, from: v } : x)))} />
          <span className="text-slate-400">→</span>
          <TextInput placeholder="target field key" value={r.to} onChange={(e) => onChange(rows.map((x, j) => (j === i ? { ...x, to: e.target.value } : x)))} />
          <Button variant="danger" onClick={() => onChange(rows.filter((_, j) => j !== i))}><Trash2 className="h-3.5 w-3.5" /></Button>
        </div>
      ))}
    </>
  );
}
