/** Resolves the icon names in ACTIVITY_META to lucide components. */
import {
  Ban, Bell, Clock, FileCode, FilePlus2, FileSearch, Flag, GitBranch, Inbox,
  ListOrdered, Merge, Pencil, Play, Plug, Send, Sigma, Split, UsersRound,
  Webhook, Workflow, Circle, type LucideIcon,
} from "lucide-react";

const ICONS: Record<string, LucideIcon> = {
  Ban, Bell, Clock, FileCode, FilePlus2, FileSearch, Flag, GitBranch, Inbox,
  ListOrdered, Merge, Pencil, Play, Plug, Send, Sigma, Split, UsersRound,
  Webhook, Workflow,
};

export function ActivityIcon({ name, className }: { name: string; className?: string }) {
  const Icon = ICONS[name] ?? Circle;
  return <Icon className={className} />;
}
