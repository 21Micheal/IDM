/**
 * ProcessTab.tsx — the whole Process tab: palette | canvas | side panel
 * (Issues / Variables / Test run), plus the settings dialog and undo/redo.
 */

import { useCallback, useEffect, useMemo, useState } from "react";
import { AlertTriangle, CheckCircle2, Download, Redo2, Undo2, Upload } from "lucide-react";
import type { ActivityType, ProcessDefinition, ProcessNode } from "@/types/process";
import { createNode, portsForNode } from "@/lib/process/activities";
import { autoLayout, validateProcess } from "@/lib/process/engine";
import { normalizeProcess, outputProcess } from "@/lib/process/serialize";
import type { ProcessFormSection } from "@/lib/process/refOptions";
import { ActivityPalette } from "./ActivityPalette";
import { ProcessCanvas, NODE_W } from "./ProcessCanvas";
import { NodeConfigModal, type Lookup } from "./NodeConfigModal";
import { VariablesPanel } from "./VariablesPanel";
import { SimulatorPanel } from "./SimulatorPanel";
import { Button } from "./ui";
import { cn } from "@/lib/utils";

export interface ProcessTabProps {
  value: ProcessDefinition;
  onChange: (def: ProcessDefinition) => void;
  sections: ProcessFormSection[];
  groups?: Lookup[];
  users?: Lookup[];
  templates?: Lookup[];
  documentTypes?: Lookup[];
  connectors?: Lookup[];
}

const HISTORY_LIMIT = 60;

export function ProcessTab(props: ProcessTabProps) {
  const { value, onChange, sections } = props;
  const [selected, setSelected] = useState<string | null>(null);
  const [editing, setEditing] = useState<string | null>(null);
  const [panel, setPanel] = useState<"issues" | "variables" | "test">("issues");
  const [trace, setTrace] = useState<{ ids: string[]; active: string | null }>({ ids: [], active: null });
  const [past, setPast] = useState<ProcessDefinition[]>([]);
  const [future, setFuture] = useState<ProcessDefinition[]>([]);

  const issues = useMemo(() => validateProcess(value), [value]);
  const errors = issues.filter((i) => i.level === "error").length;

  const commit = useCallback((next: ProcessDefinition) => {
    setPast((p) => [...p.slice(-HISTORY_LIMIT), value]);
    setFuture([]);
    onChange(next);
  }, [value, onChange]);

  const undo = () => { const prev = past.at(-1); if (!prev) return; setPast(past.slice(0, -1)); setFuture([value, ...future]); onChange(prev); };
  const redo = () => { const next = future[0]; if (!next) return; setFuture(future.slice(1)); setPast([...past, value]); onChange(next); };

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (!(e.ctrlKey || e.metaKey) || (e.target as HTMLElement)?.tagName === "INPUT") return;
      if (e.key.toLowerCase() === "z") { e.preventDefault(); if (e.shiftKey) redo(); else undo(); }
      if (e.key.toLowerCase() === "y") { e.preventDefault(); redo(); }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  });

  const addNode = (type: ActivityType, x?: number, y?: number) => {
    const index = value.nodes.filter((n) => n.type === "get_record").length;
    const maxY = Math.max(0, ...value.nodes.map((n) => n.y));
    const node = createNode(type, x ?? 380 + NODE_W + 60, y ?? maxY + 40, index);
    commit({ ...value, nodes: [...value.nodes, node] });
    setSelected(node.id);
  };

  const saveNode = (node: ProcessNode) => {
    // Drop edges whose outcome port no longer exists (e.g. Return switched off).
    const ports = new Set(portsForNode(node).map((p) => p.id));
    commit({
      ...value,
      nodes: value.nodes.map((n) => (n.id === node.id ? node : n)),
      edges: value.edges.filter((e) => e.from !== node.id || ports.has(e.fromPort)),
    });
    setEditing(null);
  };

  const exportJson = () => {
    const blob = new Blob([JSON.stringify(outputProcess(value), null, 2)], { type: "application/json" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = "process.json";
    a.click();
    URL.revokeObjectURL(a.href);
  };

  const importJson = () => {
    const input = document.createElement("input");
    input.type = "file";
    input.accept = "application/json";
    input.onchange = async () => {
      const file = input.files?.[0];
      if (!file) return;
      try { commit(normalizeProcess(JSON.parse(await file.text()))); } catch { alert("That file is not a valid process."); }
    };
    input.click();
  };

  const editingNode = value.nodes.find((n) => n.id === editing);

  return (
    <div className="flex h-full min-h-0 flex-col">
      <div className="flex items-center gap-2 border-b border-slate-200 bg-white px-3 py-1.5">
        <Button variant="ghost" disabled={!past.length} onClick={undo} title="Undo (Ctrl+Z)"><Undo2 className="h-4 w-4" /></Button>
        <Button variant="ghost" disabled={!future.length} onClick={redo} title="Redo (Ctrl+Shift+Z)"><Redo2 className="h-4 w-4" /></Button>
        <span className="mx-1 h-5 w-px bg-slate-200" />
        <Button variant="ghost" onClick={importJson}><Upload className="h-4 w-4" /> Import</Button>
        <Button variant="ghost" onClick={exportJson}><Download className="h-4 w-4" /> Export</Button>
        <span className={cn("ml-auto inline-flex items-center gap-1 text-xs", errors ? "text-rose-600" : "text-emerald-600")}>
          {errors ? <AlertTriangle className="h-4 w-4" /> : <CheckCircle2 className="h-4 w-4" />}
          {errors ? `${errors} error(s)` : "Process is valid"}
          {issues.length - errors > 0 && <span className="text-amber-600">· {issues.length - errors} warning(s)</span>}
        </span>
      </div>

      <div className="flex min-h-0 flex-1">
        <ActivityPalette hasStart={value.nodes.some((n) => n.type === "start")} onAdd={(t) => addNode(t)} />
        <div className="min-w-0 flex-1">
          <ProcessCanvas
            def={value}
            onChange={commit}
            selectedId={selected}
            onSelect={setSelected}
            onOpen={setEditing}
            onDropActivity={(t, x, y) => addNode(t, x, y)}
            onAutoLayout={() => commit(autoLayout(value))}
            issues={issues}
            highlight={trace.ids}
            activeNodeId={trace.active}
          />
        </div>
        <aside className="flex w-80 shrink-0 flex-col border-l border-slate-200 bg-white">
          <div className="flex border-b border-slate-200 text-xs font-medium">
            {([["issues", `Issues (${issues.length})`], ["variables", "Variables"], ["test", "Test run"]] as const).map(([id, label]) => (
              <button key={id} type="button" onClick={() => setPanel(id)}
                className={cn("flex-1 px-2 py-2", panel === id ? "border-b-2 border-sky-600 text-sky-700" : "text-slate-500 hover:text-slate-800")}>
                {label}
              </button>
            ))}
          </div>
          <div className="min-h-0 flex-1 overflow-y-auto">
            {panel === "issues" && (
              <ul className="space-y-1.5 p-3">
                {issues.map((i, idx) => (
                  <li key={idx}>
                    <button type="button" onClick={() => i.nodeId && setSelected(i.nodeId)}
                      className={cn("w-full rounded-md border px-2 py-1.5 text-left text-xs", i.level === "error" ? "border-rose-200 bg-rose-50 text-rose-700" : "border-amber-200 bg-amber-50 text-amber-800")}>
                      {i.message}
                    </button>
                  </li>
                ))}
                {!issues.length && <li className="text-xs text-emerald-600">No issues found.</li>}
              </ul>
            )}
            {panel === "variables" && <VariablesPanel def={value} onChange={commit} />}
            {panel === "test" && <SimulatorPanel def={value} sections={sections} onTrace={(ids, active) => setTrace({ ids, active })} />}
          </div>
        </aside>
      </div>

      {editingNode && (
        <NodeConfigModal
          node={editingNode}
          def={value}
          sections={sections}
          groups={props.groups}
          users={props.users}
          templates={props.templates}
          documentTypes={props.documentTypes}
          connectors={props.connectors}
          onSave={saveNode}
          onClose={() => setEditing(null)}
        />
      )}
    </div>
  );
}
