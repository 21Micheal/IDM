/** VariablesPanel.tsx — process variables + process-wide settings. */

import { Plus, Trash2 } from "lucide-react";
import type { ProcessDefinition, ProcessVariable, VariableType } from "@/types/process";
import { uid } from "@/lib/process/activities";
import { Button, Field, SectionTitle, Select, TextInput, Toggle } from "./ui";

const TYPES: VariableType[] = ["text", "number", "currency", "boolean", "date", "json", "user", "list"];

export function VariablesPanel({ def, onChange }: { def: ProcessDefinition; onChange: (d: ProcessDefinition) => void }) {
  const vars = def.variables;
  const update = (i: number, patch: Partial<ProcessVariable>) =>
    onChange({ ...def, variables: vars.map((v, j) => (j === i ? { ...v, ...patch } : v)) });
  const s = def.settings;

  return (
    <div className="p-3">
      <SectionTitle right={
        <Button variant="ghost" onClick={() => onChange({ ...def, variables: [...vars, { id: uid("var"), key: `var_${vars.length + 1}`, label: `Variable ${vars.length + 1}`, type: "text", initial: "" }] })}>
          <Plus className="h-3.5 w-3.5" /> Add
        </Button>
      }>Variables</SectionTitle>
      {vars.map((v, i) => (
        <div key={v.id} className="mb-2 space-y-1.5 rounded-md border border-slate-200 p-2">
          <div className="flex gap-1.5">
            <TextInput className="font-mono text-xs" value={v.key} onChange={(e) => update(i, { key: e.target.value.replace(/[^a-zA-Z0-9_]/g, "_") })} />
            <Select className="w-28 text-xs" value={v.type} onChange={(e) => update(i, { type: e.target.value as VariableType })}>
              {TYPES.map((t) => <option key={t}>{t}</option>)}
            </Select>
            <button type="button" className="px-1 text-slate-400 hover:text-rose-500" onClick={() => onChange({ ...def, variables: vars.filter((_, j) => j !== i) })}>
              <Trash2 className="h-4 w-4" />
            </button>
          </div>
          <TextInput className="text-xs" placeholder="Label" value={v.label} onChange={(e) => update(i, { label: e.target.value })} />
          <TextInput className="text-xs" placeholder="Initial value or {{field.key}}" value={v.initial ?? ""} onChange={(e) => update(i, { initial: e.target.value })} />
          <label className="flex items-center gap-2 text-[11px] text-slate-500">
            <input type="checkbox" checked={!!v.exposed} onChange={(e) => update(i, { exposed: e.target.checked })} /> Show on document page
          </label>
        </div>
      ))}
      {!vars.length && <p className="text-xs text-slate-400">Variables hold values between activities (counters, totals, chosen approvers).</p>}

      <SectionTitle>Process settings</SectionTitle>
      <div className="space-y-2">
        <Toggle checked={!!s.restartOnResubmit} onChange={(v) => onChange({ ...def, settings: { ...s, restartOnResubmit: v } })} label="Restart from Start on resubmit" hint="Otherwise resume at the step that returned it" />
        <Toggle checked={s.notifyInitiatorOnStatusChange !== false} onChange={(v) => onChange({ ...def, settings: { ...s, notifyInitiatorOnStatusChange: v } })} label="Notify initiator on every status change" />
        <Field label="Cancel instance after (hours, 0 = never)">
          <TextInput type="number" value={s.instanceSlaHours ?? 0} onChange={(e) => onChange({ ...def, settings: { ...s, instanceSlaHours: Number(e.target.value) || undefined } })} />
        </Field>
      </div>
    </div>
  );
}
