/**
 * ui.tsx — tiny presentational primitives shared by the process builder.
 *
 * Deliberately dependency-light: only react + lucide-react + `cn`. Swap these
 * for your own shadcn components if you prefer; nothing else in the package
 * depends on their internals.
 */

import type { ReactNode } from "react";
import { X } from "lucide-react";
import { cn } from "@/lib/utils";

export function Field({
  label, hint, children, className,
}: { label: string; hint?: string; children: ReactNode; className?: string }) {
  return (
    <label className={cn("block", className)}>
      <span className="mb-1 block text-xs font-medium text-slate-600">{label}</span>
      {children}
      {hint ? <span className="mt-1 block text-[11px] text-slate-400">{hint}</span> : null}
    </label>
  );
}

export const inputCls =
  "w-full rounded-md border border-slate-300 bg-white px-2.5 py-1.5 text-sm text-slate-900 " +
  "outline-none transition focus:border-sky-400 focus:ring-2 focus:ring-sky-100 " +
  "disabled:cursor-not-allowed disabled:bg-slate-50";

export function TextInput(props: React.InputHTMLAttributes<HTMLInputElement>) {
  return <input {...props} className={cn(inputCls, props.className)} />;
}

export function TextArea(props: React.TextareaHTMLAttributes<HTMLTextAreaElement>) {
  return <textarea {...props} className={cn(inputCls, "min-h-[80px] resize-y font-mono text-[12px]", props.className)} />;
}

export function Select(props: React.SelectHTMLAttributes<HTMLSelectElement>) {
  return <select {...props} className={cn(inputCls, "pr-7", props.className)} />;
}

export function Toggle({
  checked, onChange, label, hint,
}: { checked: boolean; onChange: (v: boolean) => void; label: string; hint?: string }) {
  return (
    <button
      type="button"
      onClick={() => onChange(!checked)}
      className="flex w-full items-start gap-3 rounded-md border border-slate-200 px-3 py-2 text-left transition hover:bg-slate-50"
    >
      <span
        className={cn(
          "mt-0.5 inline-flex h-5 w-9 shrink-0 items-center rounded-full p-0.5 transition",
          checked ? "bg-sky-500" : "bg-slate-300",
        )}
      >
        <span className={cn("h-4 w-4 rounded-full bg-white transition", checked && "translate-x-4")} />
      </span>
      <span>
        <span className="block text-sm text-slate-800">{label}</span>
        {hint ? <span className="block text-[11px] text-slate-500">{hint}</span> : null}
      </span>
    </button>
  );
}

export function Chip({ children, onRemove }: { children: ReactNode; onRemove?: () => void }) {
  return (
    <span className="inline-flex items-center gap-1 rounded-full bg-slate-100 px-2 py-0.5 text-xs text-slate-700">
      {children}
      {onRemove ? (
        <button type="button" onClick={onRemove} className="text-slate-400 hover:text-rose-500">
          <X className="h-3 w-3" />
        </button>
      ) : null}
    </span>
  );
}

/** Comma/enter separated list editor used for emails, groups and field keys. */
export function ListEditor({
  values, onChange, placeholder,
}: { values: string[]; onChange: (v: string[]) => void; placeholder?: string }) {
  return (
    <div className="rounded-md border border-slate-300 bg-white p-2">
      <div className="mb-1 flex flex-wrap gap-1">
        {values.map((v, i) => (
          <Chip key={`${v}-${i}`} onRemove={() => onChange(values.filter((_, idx) => idx !== i))}>{v}</Chip>
        ))}
        {!values.length ? <span className="text-xs text-slate-400">None</span> : null}
      </div>
      <input
        className="w-full border-0 p-0 text-sm outline-none placeholder:text-slate-400"
        placeholder={placeholder ?? "Type and press Enter"}
        onKeyDown={(e) => {
          if (e.key !== "Enter" && e.key !== ",") return;
          e.preventDefault();
          const raw = (e.target as HTMLInputElement).value.trim().replace(/,$/, "");
          if (!raw) return;
          onChange([...values, raw]);
          (e.target as HTMLInputElement).value = "";
        }}
      />
    </div>
  );
}

export function SectionTitle({ children, right }: { children: ReactNode; right?: ReactNode }) {
  return (
    <div className="mb-2 mt-4 flex items-center justify-between border-b border-slate-200 pb-1 first:mt-0">
      <h4 className="text-[11px] font-semibold uppercase tracking-wide text-slate-500">{children}</h4>
      {right}
    </div>
  );
}

export function Modal({
  title, subtitle, onClose, children, footer, width = "max-w-3xl",
}: {
  title: string; subtitle?: string; onClose: () => void;
  children: ReactNode; footer?: ReactNode; width?: string;
}) {
  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center overflow-y-auto bg-slate-900/40 p-6">
      <div className={cn("w-full rounded-xl bg-white shadow-2xl", width)}>
        <header className="flex items-start justify-between border-b border-slate-200 px-5 py-3">
          <div>
            <h3 className="text-sm font-semibold text-slate-900">{title}</h3>
            {subtitle ? <p className="text-xs text-slate-500">{subtitle}</p> : null}
          </div>
          <button type="button" onClick={onClose} className="rounded p-1 text-slate-400 hover:bg-slate-100 hover:text-slate-700">
            <X className="h-4 w-4" />
          </button>
        </header>
        <div className="max-h-[70vh] overflow-y-auto px-5 py-4">{children}</div>
        {footer ? <footer className="flex justify-end gap-2 border-t border-slate-200 px-5 py-3">{footer}</footer> : null}
      </div>
    </div>
  );
}

export function Button({
  variant = "default", className, ...props
}: React.ButtonHTMLAttributes<HTMLButtonElement> & { variant?: "default" | "primary" | "danger" | "ghost" }) {
  const styles = {
    default: "border border-slate-300 bg-white text-slate-700 hover:bg-slate-50",
    primary: "bg-sky-600 text-white hover:bg-sky-700",
    danger: "border border-rose-200 bg-white text-rose-600 hover:bg-rose-50",
    ghost: "text-slate-500 hover:bg-slate-100",
  }[variant];
  return (
    <button
      type="button"
      {...props}
      className={cn("inline-flex items-center gap-1.5 rounded-md px-3 py-1.5 text-sm font-medium transition", styles, className)}
    />
  );
}
