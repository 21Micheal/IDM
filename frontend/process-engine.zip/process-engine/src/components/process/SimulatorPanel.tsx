/**
 * SimulatorPanel.tsx — "test run" the process with sample values and per-step
 * decisions, highlighting the path taken on the canvas.
 */

import { useMemo, useState } from "react";
import { Play, RotateCcw } from "lucide-react";
import type { ProcessDefinition, SimulationState } from "@/types/process";
import { portsForNode } from "@/lib/process/activities";
import { simulateProcess } from "@/lib/process/engine";
import { formFields, type ProcessFormSection } from "@/lib/process/refOptions";
import { Button, SectionTitle, Select, TextInput } from "./ui";
import { cn } from "@/lib/utils";

export function SimulatorPanel({
  def, sections, onTrace,
}: { def: ProcessDefinition; sections: ProcessFormSection[]; onTrace: (nodeIds: string[], active: string | null) => void }) {
  const fields = useMemo(() => formFields(sections), [sections]);
  const [values, setValues] = useState<Record<string, string>>({});
  const [decisions, setDecisions] = useState<Record<string, string>>({});
  const [result, setResult] = useState<SimulationState | null>(null);
  const assignments = def.nodes.filter((n) => n.type === "assignment");

  const run = () => {
    const typed: Record<string, unknown> = {};
    for (const [k, v] of Object.entries(values)) typed[k] = v !== "" && !Number.isNaN(Number(v)) ? Number(v) : v;
    const r = simulateProcess(def, { values: typed, decisions });
    setResult(r);
    onTrace(r.trace.map((t) => t.nodeId), r.trace.at(-1)?.nodeId ?? null);
  };

  const reset = () => { setResult(null); onTrace([], null); };

  return (
    <div className="p-3">
      <SectionTitle>Sample values</SectionTitle>
      <div className="max-h-56 space-y-1.5 overflow-y-auto">
        {fields.map((f) => (
          <label key={f.key} className="flex items-center gap-2 text-xs">
            <span className="w-28 shrink-0 truncate text-slate-600" title={f.key}>{f.label}</span>
            <TextInput className="py-1 text-xs" value={values[f.key] ?? ""} onChange={(e) => setValues({ ...values, [f.key]: e.target.value })} />
          </label>
        ))}
        {!fields.length && <p className="text-xs text-slate-400">No form fields yet.</p>}
      </div>

      {assignments.length > 0 && (
        <>
          <SectionTitle>Decisions</SectionTitle>
          <div className="space-y-1.5">
            {assignments.map((n) => (
              <label key={n.id} className="flex items-center gap-2 text-xs">
                <span className="w-28 shrink-0 truncate text-slate-600">{n.name}</span>
                <Select className="py-1 text-xs" value={decisions[n.id] ?? "approved"} onChange={(e) => setDecisions({ ...decisions, [n.id]: e.target.value })}>
                  {portsForNode(n).map((p) => <option key={p.id} value={p.id}>{p.label}</option>)}
                </Select>
              </label>
            ))}
          </div>
        </>
      )}

      <div className="mt-3 flex gap-2">
        <Button variant="primary" onClick={run}><Play className="h-3.5 w-3.5" /> Run</Button>
        <Button onClick={reset}><RotateCcw className="h-3.5 w-3.5" /> Clear</Button>
      </div>

      {result && (
        <>
          <SectionTitle>Trace</SectionTitle>
          <ol className="space-y-1.5">
            {result.trace.map((t, i) => (
              <li key={`${t.nodeId}-${i}`} className="rounded-md border border-slate-200 bg-white p-2 text-xs">
                <div className="flex items-center gap-1.5">
                  <span className="font-mono text-slate-400">{i + 1}</span>
                  <span className="font-medium text-slate-800">{t.nodeName}</span>
                  {t.outPort && <span className="ml-auto rounded bg-slate-100 px-1.5 text-[10px] text-slate-600">{t.outPort}</span>}
                </div>
                <div className="mt-0.5 text-slate-500">{t.detail}</div>
              </li>
            ))}
          </ol>
          <div className={cn("mt-2 rounded-md p-2 text-xs", result.error ? "bg-rose-50 text-rose-700" : "bg-emerald-50 text-emerald-700")}>
            {result.error ?? `Finished — final status “${result.finalStatus}”.`}
          </div>
          {Object.keys(result.variables).length > 0 && (
            <pre className="mt-2 overflow-x-auto rounded bg-slate-900 p-2 text-[10px] text-slate-100">{JSON.stringify(result.variables, null, 2)}</pre>
          )}
        </>
      )}
    </div>
  );
}
