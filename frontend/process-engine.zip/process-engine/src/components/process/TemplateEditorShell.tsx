/**
 * TemplateEditorShell.tsx — tabbed editor: Form | Process | Preview | Default Columns.
 *
 * Wraps your existing TemplateBuilderV2 (unchanged) as the Form tab and owns
 * the single Save that sends sections + process + default_columns together.
 *
 * Usage:
 *   <TemplateEditorShell
 *     initial={template}
 *     renderForm={({ template, onSectionsChange }) => (
 *       <TemplateBuilderV2 initial={template} embedded onChange={(t) => onSectionsChange(t.sections)} ... />
 *     )}
 *     renderPreview={(template) => <YourFormRenderer template={template} />}
 *     onSave={(payload) => templatesAPI.update(id, payload)}
 *   />
 */

import { useMemo, useState, type ReactNode } from "react";
import { Columns3, Eye, FileText, Save, Workflow } from "lucide-react";
import type { DefaultColumn, ProcessDefinition } from "@/types/process";
import { validateProcess } from "@/lib/process/engine";
import { normalizeDefaultColumns, normalizeProcess, outputProcess } from "@/lib/process/serialize";
import type { ProcessFormSection } from "@/lib/process/refOptions";
import { ProcessTab } from "./ProcessTab";
import { DefaultColumnsTab } from "./DefaultColumnsTab";
import type { Lookup } from "./NodeConfigModal";
import { Button } from "./ui";
import { cn } from "@/lib/utils";

export interface ProcessAwareTemplate {
  id?: string;
  name: string;
  sections: ProcessFormSection[];
  process?: unknown;
  default_columns?: unknown;
  [key: string]: unknown;
}

export interface TemplateSavePayload<T> {
  template: T;
  process: ProcessDefinition;
  default_columns: DefaultColumn[];
}

type Tab = "form" | "process" | "preview" | "columns";

export interface TemplateEditorShellProps<T extends ProcessAwareTemplate> {
  initial: T;
  renderForm: (api: { template: T; onTemplateChange: (t: T) => void; onSectionsChange: (s: T["sections"]) => void }) => ReactNode;
  renderPreview?: (template: T, process: ProcessDefinition) => ReactNode;
  onSave: (payload: TemplateSavePayload<T>) => void | Promise<unknown>;
  onCancel?: () => void;
  isSaving?: boolean;
  /** Blocks Save while the process has errors (default true). */
  blockOnErrors?: boolean;
  groups?: Lookup[];
  users?: Lookup[];
  templates?: Lookup[];
  documentTypes?: Lookup[];
  connectors?: Lookup[];
}

export function TemplateEditorShell<T extends ProcessAwareTemplate>(props: TemplateEditorShellProps<T>) {
  const { initial, renderForm, renderPreview, onSave, onCancel, isSaving, blockOnErrors = true } = props;
  const [tab, setTab] = useState<Tab>("form");
  const [template, setTemplate] = useState<T>(initial);
  const [process, setProcess] = useState<ProcessDefinition>(() => normalizeProcess(initial.process));
  const [columns, setColumns] = useState<DefaultColumn[]>(() => normalizeDefaultColumns(initial.default_columns));
  const [dirty, setDirty] = useState(false);

  const errors = useMemo(() => validateProcess(process).filter((i) => i.level === "error").length, [process]);

  const tabs: { id: Tab; label: string; icon: ReactNode; badge?: number }[] = [
    { id: "form", label: "Form", icon: <FileText className="h-4 w-4" /> },
    { id: "process", label: "Process", icon: <Workflow className="h-4 w-4" />, badge: errors || undefined },
    { id: "preview", label: "Preview", icon: <Eye className="h-4 w-4" /> },
    { id: "columns", label: "Default Columns", icon: <Columns3 className="h-4 w-4" /> },
  ];

  const save = () => {
    if (blockOnErrors && errors) { setTab("process"); return; }
    void onSave({ template: { ...template, process: outputProcess(process), default_columns: columns }, process: outputProcess(process), default_columns: columns });
    setDirty(false);
  };

  return (
    <div className="flex h-screen flex-col bg-slate-50">
      <header className="flex items-center gap-3 border-b border-slate-200 bg-white px-4 py-2">
        <input
          value={template.name}
          onChange={(e) => { setTemplate({ ...template, name: e.target.value }); setDirty(true); }}
          className="w-72 rounded border border-transparent px-2 py-1 text-sm font-semibold text-slate-900 hover:border-slate-200 focus:border-sky-400 focus:outline-none"
        />
        <nav className="flex gap-1">
          {tabs.map((t) => (
            <button key={t.id} type="button" onClick={() => setTab(t.id)}
              className={cn("inline-flex items-center gap-1.5 rounded-md px-3 py-1.5 text-sm font-medium", tab === t.id ? "bg-sky-50 text-sky-700" : "text-slate-500 hover:bg-slate-100")}>
              {t.icon}{t.label}
              {t.badge ? <span className="rounded-full bg-rose-500 px-1.5 text-[10px] text-white">{t.badge}</span> : null}
            </button>
          ))}
        </nav>
        <div className="ml-auto flex items-center gap-2">
          {dirty && <span className="text-xs text-amber-600">Unsaved changes</span>}
          {onCancel && <Button onClick={onCancel}>Cancel</Button>}
          <Button variant="primary" disabled={isSaving} onClick={save} title={errors && blockOnErrors ? "Fix process errors first" : undefined}>
            <Save className="h-4 w-4" /> {isSaving ? "Saving…" : "Save"}
          </Button>
        </div>
      </header>

      <main className="min-h-0 flex-1">
        <div className={cn("h-full overflow-auto", tab !== "form" && "hidden")}>
          {renderForm({
            template,
            onTemplateChange: (t) => { setTemplate(t); setDirty(true); },
            onSectionsChange: (sections) => { setTemplate((t) => ({ ...t, sections })); setDirty(true); },
          })}
        </div>
        {tab === "process" && (
          <ProcessTab
            value={process}
            onChange={(d) => { setProcess(d); setDirty(true); }}
            sections={template.sections}
            groups={props.groups}
            users={props.users}
            templates={props.templates}
            documentTypes={props.documentTypes}
            connectors={props.connectors}
          />
        )}
        {tab === "preview" && (
          <div className="h-full overflow-auto p-6">
            {renderPreview ? renderPreview(template, process) : <p className="text-sm text-slate-500">Pass renderPreview to show the live form.</p>}
          </div>
        )}
        {tab === "columns" && (
          <div className="h-full overflow-auto">
            <DefaultColumnsTab columns={columns} onChange={(c) => { setColumns(c); setDirty(true); }} sections={template.sections} process={process} />
          </div>
        )}
      </main>
    </div>
  );
}
