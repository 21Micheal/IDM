/**
 * processApi.ts — add these to your api.ts (uses the same axios `api` instance).
 * Endpoints are described in README "Backend contract".
 */

import type { ProcessDefinition, DefaultColumn } from "@/types/process";

// Replace with: import { api } from "./api";
type Http = { get: (u: string, c?: unknown) => Promise<unknown>; post: (u: string, d?: unknown) => Promise<unknown>; patch: (u: string, d?: unknown) => Promise<unknown> };

export function createProcessAPI(api: Http) {
  return {
    /** Save form + process + columns in one PATCH (templatesAPI.update shape). */
    saveTemplate: (id: string, data: { sections: unknown; process: ProcessDefinition; default_columns: DefaultColumn[]; [k: string]: unknown }) =>
      api.patch(`/templates/${id}/`, data),
    /** Server-side validation (same rules as validateProcess, authoritative). */
    validate: (process: ProcessDefinition) => api.post("/process/validate/", { process }),
    /** Convert a legacy workflow template into a process graph server-side. */
    migrateWorkflow: (workflowTemplateId: string) => api.post(`/process/migrate/${workflowTemplateId}/`),
    /** Runtime: instance state, history and the current user's pending task. */
    getInstance: (documentId: string) => api.get(`/documents/${documentId}/process/`),
    /** Runtime: action an assignment. outcome = approved | rejected | returned | <custom port>. */
    act: (documentId: string, body: { node_id: string; outcome: string; comment?: string; signature?: string; values?: Record<string, unknown> }) =>
      api.post(`/documents/${documentId}/process/act/`, body),
    delegate: (documentId: string, body: { node_id: string; user_id: string; comment?: string }) =>
      api.post(`/documents/${documentId}/process/delegate/`, body),
    /** Runtime: effective section/field access for the current user at the current step. */
    getAccess: (documentId: string) => api.get(`/documents/${documentId}/process/access/`),
  };
}
