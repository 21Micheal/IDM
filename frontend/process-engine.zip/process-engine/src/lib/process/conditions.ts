/**
 * conditions.ts — token resolution + rule evaluation shared by the process
 * builder (preview badges), the simulator, and any client-side guard.
 *
 * The SAME grammar must exist server-side; the browser copy is for authoring
 * feedback only and is never authoritative. See README "Backend contract".
 *
 * Tokens
 *   {{field.amount}}        a form field value by KEY
 *   {{var.retry_count}}     a process variable
 *   {{GCR0.status}}         a record loaded by a Get Current Record activity
 *   {{ctx.initiator_name}}  runtime context
 *   {{ctx.now}}             ISO timestamp
 *
 * Expressions
 *   Tokens may be embedded in free text ("Invoice {{field.reference}} approved")
 *   or used arithmetically ("{{field.amount}} * 0.16"). evaluateExpression()
 *   interpolates first, then tries a numeric evaluation; if the result is not
 *   a clean number it returns the interpolated string.
 */

import type { ProcessCondition, RuleGroup } from "@/types/process";

export interface EvalScope {
  values: Record<string, unknown>;              // form field values by key
  variables: Record<string, unknown>;           // process variables by key
  records: Record<string, Record<string, unknown>>; // alias → record
  context: Record<string, unknown>;             // initiator, now, step…
}

export function emptyScope(partial: Partial<EvalScope> = {}): EvalScope {
  return {
    values: partial.values ?? {},
    variables: partial.variables ?? {},
    records: partial.records ?? {},
    context: { now: new Date().toISOString(), ...(partial.context ?? {}) },
  };
}

/* ── token resolution ──────────────────────────────────────────────────── */

const TOKEN_RE = /\{\{\s*([a-zA-Z0-9_.[\]]+)\s*\}\}/g;

function readPath(root: unknown, path: string[]): unknown {
  let cur: unknown = root;
  for (const part of path) {
    if (cur === null || cur === undefined) return undefined;
    if (Array.isArray(cur)) {
      const idx = Number(part);
      cur = Number.isFinite(idx) ? cur[idx] : undefined;
    } else if (typeof cur === "object") {
      cur = (cur as Record<string, unknown>)[part];
    } else return undefined;
  }
  return cur;
}

/** Resolve a dotted reference against the scope. Understands the four
 *  namespaces plus a bare key, which falls back to a form field. */
export function resolveRef(ref: string, scope: EvalScope): unknown {
  const clean = (ref ?? "").trim().replace(/^\{\{|\}\}$/g, "").trim();
  if (!clean) return undefined;
  const parts = clean.split(".");
  const head = parts[0];
  const rest = parts.slice(1);

  if (head === "field" || head === "form") return readPath(scope.values, rest);
  if (head === "var" || head === "variable") return readPath(scope.variables, rest);
  if (head === "ctx" || head === "context") return readPath(scope.context, rest);
  if (Object.prototype.hasOwnProperty.call(scope.records, head)) {
    return readPath(scope.records[head], rest);
  }
  // "field:key" form used by assignment targets
  if (clean.startsWith("field:")) return scope.values[clean.slice(6)];
  if (clean.startsWith("var:")) return scope.variables[clean.slice(4)];
  return readPath(scope.values, parts);
}

/** Replace every {{token}} in a string with its resolved value. */
export function interpolate(text: string, scope: EvalScope): string {
  if (!text) return "";
  return text.replace(TOKEN_RE, (_m, ref: string) => {
    const v = resolveRef(ref, scope);
    if (v === null || v === undefined) return "";
    if (typeof v === "object") return JSON.stringify(v);
    return String(v);
  });
}

/* ── arithmetic ────────────────────────────────────────────────────────── */

const SAFE_MATH = /^[0-9+\-*/%().,\s]*$/;

/** Evaluate a numeric expression made only of literals and operators.
 *  Returns NaN for anything unsafe or malformed — never throws. */
export function evaluateNumeric(expr: string): number {
  const cleaned = (expr ?? "").replace(/,/g, "").trim();
  if (!cleaned || !SAFE_MATH.test(cleaned)) return NaN;
  try {
    // eslint-disable-next-line no-new-func
    const fn = new Function(`"use strict"; return (${cleaned});`) as () => unknown;
    const out = fn();
    return typeof out === "number" && Number.isFinite(out) ? out : NaN;
  } catch {
    return NaN;
  }
}

/** Interpolate then, when the result looks arithmetic, fold it to a number. */
export function evaluateExpression(expr: string, scope: EvalScope): unknown {
  const interpolated = interpolate(expr ?? "", scope);
  if (!interpolated.trim()) return "";
  const n = evaluateNumeric(interpolated);
  if (!Number.isNaN(n) && /[+\-*/%]/.test(interpolated)) return n;
  if (/^-?\d+(\.\d+)?$/.test(interpolated.trim())) return Number(interpolated.trim());
  if (interpolated === "true") return true;
  if (interpolated === "false") return false;
  return interpolated;
}

/* ── comparison ────────────────────────────────────────────────────────── */

function toNumber(v: unknown): number {
  if (typeof v === "number") return v;
  if (typeof v === "boolean") return v ? 1 : 0;
  const n = Number(String(v ?? "").replace(/[^0-9.\-]/g, ""));
  return Number.isFinite(n) ? n : NaN;
}

function toText(v: unknown): string {
  if (v === null || v === undefined) return "";
  if (typeof v === "object") return JSON.stringify(v);
  return String(v);
}

function isEmpty(v: unknown): boolean {
  if (v === null || v === undefined) return true;
  if (typeof v === "string") return v.trim() === "";
  if (Array.isArray(v)) return v.length === 0;
  return false;
}

function splitList(raw: string | undefined): string[] {
  return (raw ?? "").split(",").map((s) => s.trim()).filter(Boolean);
}

export function compare(left: unknown, operator: string, rawRight?: string, rawRight2?: string): boolean {
  const right = rawRight ?? "";
  switch (operator) {
    case "is_empty": return isEmpty(left);
    case "is_not_empty": return !isEmpty(left);
    case "is_true": return left === true || toText(left).toLowerCase() === "true" || toNumber(left) === 1;
    case "is_false": return left === false || toText(left).toLowerCase() === "false" || toNumber(left) === 0;
    case "equals": return toText(left).toLowerCase() === right.trim().toLowerCase();
    case "not_equals": return toText(left).toLowerCase() !== right.trim().toLowerCase();
    case "greater_than": return toNumber(left) > toNumber(right);
    case "greater_or_equal": return toNumber(left) >= toNumber(right);
    case "less_than": return toNumber(left) < toNumber(right);
    case "less_or_equal": return toNumber(left) <= toNumber(right);
    case "between":
    case "not_between": {
      const parts = rawRight2 !== undefined && rawRight2 !== "" ? [right, rawRight2] : splitList(right);
      const lo = toNumber(parts[0]);
      const hi = toNumber(parts[1]);
      const n = toNumber(left);
      const inside = n >= Math.min(lo, hi) && n <= Math.max(lo, hi);
      return operator === "between" ? inside : !inside;
    }
    case "contains": return toText(left).toLowerCase().includes(right.toLowerCase());
    case "not_contains": return !toText(left).toLowerCase().includes(right.toLowerCase());
    case "starts_with": return toText(left).toLowerCase().startsWith(right.toLowerCase());
    case "ends_with": return toText(left).toLowerCase().endsWith(right.toLowerCase());
    case "in_list": return splitList(right).map((s) => s.toLowerCase()).includes(toText(left).toLowerCase());
    case "not_in_list": return !splitList(right).map((s) => s.toLowerCase()).includes(toText(left).toLowerCase());
    default: return true;
  }
}

/* ── rule groups ───────────────────────────────────────────────────────── */

export function evaluateCondition(cond: ProcessCondition, scope: EvalScope): boolean {
  const left = cond.source === "expression"
    ? evaluateExpression(cond.ref ?? "", scope)
    : resolveRef(cond.ref ?? "", scope);
  const right = cond.value !== undefined ? interpolate(cond.value, scope) : undefined;
  const right2 = cond.value2 !== undefined ? interpolate(cond.value2, scope) : undefined;
  return compare(left, cond.operator, right, right2);
}

/** Empty group = no restriction = true. */
export function evaluateRuleGroup(group: RuleGroup | null | undefined, scope: EvalScope): boolean {
  if (!group) return true;
  const results: boolean[] = [
    ...(group.conditions ?? []).map((c) => evaluateCondition(c, scope)),
    ...(group.groups ?? []).map((g) => evaluateRuleGroup(g, scope)),
  ];
  if (results.length === 0) return true;
  return group.combinator === "or" ? results.some(Boolean) : results.every(Boolean);
}

export function ruleGroupHasConditions(g?: RuleGroup | null): boolean {
  if (!g) return false;
  return (g.conditions?.length ?? 0) > 0 || (g.groups ?? []).some(ruleGroupHasConditions);
}

export function emptyRuleGroup(): RuleGroup {
  return { combinator: "and", conditions: [], groups: [] };
}

/** Human-readable summary used on node cards ("Amount > 50,000 AND Dept = IT"). */
export function describeRuleGroup(g?: RuleGroup | null, depth = 0): string {
  if (!ruleGroupHasConditions(g) || !g) return "always";
  const join = g.combinator === "or" ? " OR " : " AND ";
  const parts = [
    ...(g.conditions ?? []).map((c) => {
      const ref = (c.ref ?? "?").replace(/^field\./, "");
      const op = c.operator.replace(/_/g, " ");
      const val = c.value ? ` ${c.value}` : "";
      return `${ref} ${op}${val}`.trim();
    }),
    ...(g.groups ?? []).filter(ruleGroupHasConditions).map((sub) => `(${describeRuleGroup(sub, depth + 1)})`),
  ];
  return parts.join(join);
}
