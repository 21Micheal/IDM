/**
 * engine.ts — validation, auto-layout and a client-side simulator for a
 * ProcessDefinition.
 *
 * The simulator is a design-time aid: it walks the graph with sample form
 * values so the designer can prove the routing (amount thresholds, skip rules,
 * parallel branches) before publishing. It never calls the network — HTTP and
 * connector activities are reported as "would call …". The authoritative
 * runtime is the server engine described in README "Backend contract".
 */

import type {
  ActivityConfig, ProcessDefinition, ProcessNode, SimulationState,
  SimulationStep, ValidationIssue,
} from "@/types/process";
import { ACTIVITY_META, portsForNode } from "./activities";
import {
  describeRuleGroup, emptyScope, evaluateExpression, evaluateRuleGroup,
  interpolate, resolveRef, type EvalScope,
} from "./conditions";

/* ── validation ────────────────────────────────────────────────────────── */

export function validateProcess(def: ProcessDefinition): ValidationIssue[] {
  const issues: ValidationIssue[] = [];
  const nodes = def.nodes ?? [];
  const edges = def.edges ?? [];
  const byId = new Map(nodes.map((n) => [n.id, n]));

  const starts = nodes.filter((n) => n.type === "start");
  if (starts.length === 0) issues.push({ level: "error", message: "The process needs a Start Process activity." });
  if (starts.length > 1) issues.push({ level: "error", message: "Only one Start Process activity is allowed." });
  if (!nodes.some((n) => n.type === "completed")) {
    issues.push({ level: "error", message: "The process needs at least one CompletedProcess activity." });
  }

  for (const edge of edges) {
    if (!byId.has(edge.from) || !byId.has(edge.to)) {
      issues.push({ level: "error", edgeId: edge.id, message: "A connection points at a deleted activity." });
    }
  }

  for (const node of nodes) {
    const ports = portsForNode(node);
    const out = edges.filter((e) => e.from === node.id);
    const terminal = node.type === "completed" || node.type === "terminate";

    if (!terminal) {
      for (const port of ports) {
        if (!out.some((e) => e.fromPort === port.id)) {
          issues.push({
            level: port.tone === "negative" || port.tone === "warning" ? "warning" : "error",
            nodeId: node.id,
            message: `“${node.name}” has no connection on the “${port.label}” outcome.`,
          });
        }
      }
    }

    if (node.type !== "start" && !edges.some((e) => e.to === node.id)) {
      issues.push({ level: "warning", nodeId: node.id, message: `“${node.name}” is never reached.` });
    }

    issues.push(...validateConfig(node));
  }

  // Duplicate Get Current Record aliases make later references ambiguous.
  const aliases = new Map<string, number>();
  for (const n of nodes) {
    if (n.config.kind === "get_record") {
      const a = n.config.alias?.trim();
      if (a) aliases.set(a, (aliases.get(a) ?? 0) + 1);
    }
  }
  for (const [alias, count] of aliases) {
    if (count > 1) issues.push({ level: "error", message: `Record alias “${alias}” is used by ${count} activities.` });
  }

  return issues;
}

function validateConfig(node: ProcessNode): ValidationIssue[] {
  const out: ValidationIssue[] = [];
  const cfg = node.config;
  const err = (message: string) => out.push({ level: "error", nodeId: node.id, message });
  const warn = (message: string) => out.push({ level: "warning", nodeId: node.id, message });

  switch (cfg.kind) {
    case "assignment": {
      if (!cfg.statusLabel?.trim()) err(`“${node.name}” needs a status label.`);
      if (cfg.assigneeType === "group_any" || cfg.assigneeType === "group_all" || cfg.assigneeType === "group_specific") {
        if (!cfg.assigneeGroup) err(`“${node.name}” has no assignee group.`);
      }
      if (cfg.assigneeType === "user" && !cfg.assigneeUser) err(`“${node.name}” has no assignee.`);
      if ((cfg.assigneeType === "field_user" || cfg.assigneeType === "variable") && !cfg.assigneeRef) {
        err(`“${node.name}” has no assignee reference.`);
      }
      if (!cfg.allowApprove && !cfg.allowReject) warn(`“${node.name}” allows neither approve nor reject.`);
      break;
    }
    case "notification": {
      if (!cfg.subject?.trim()) err(`“${node.name}” needs an email subject.`);
      const hasRecipient = cfg.toInitiator || (cfg.toUsers?.length ?? 0) || (cfg.toGroups?.length ?? 0)
        || (cfg.toEmails?.length ?? 0) || (cfg.toFieldKeys?.length ?? 0);
      if (!hasRecipient) err(`“${node.name}” has no recipients.`);
      break;
    }
    case "set_value":
      if (!cfg.assignments?.length) warn(`“${node.name}” sets nothing.`);
      cfg.assignments?.forEach((a) => { if (!a.target) err(`“${node.name}” has an assignment with no target.`); });
      break;
    case "calculate":
      if (!cfg.target) err(`“${node.name}” has no target.`);
      if (!cfg.expression?.trim()) err(`“${node.name}” has no expression.`);
      break;
    case "if_else":
      if (!cfg.rules?.conditions?.length && !cfg.rules?.groups?.length) err(`“${node.name}” has no condition.`);
      break;
    case "switch":
      if (!cfg.cases?.length) err(`“${node.name}” has no cases.`);
      break;
    case "get_record":
      if (!cfg.alias?.trim()) err(`“${node.name}” needs an alias.`);
      if (cfg.source === "lookup" && !cfg.match) err(`“${node.name}” needs a match rule for a lookup.`);
      break;
    case "http_request":
    case "http_background":
      if (!cfg.url?.trim()) err(`“${node.name}” has no URL.`);
      break;
    case "data_connector":
      if (!cfg.connector) err(`“${node.name}” has no connector selected.`);
      break;
    case "create_document":
    case "sub_process":
      if (!cfg.templateId) err(`“${node.name}” has no template selected.`);
      break;
    case "completed":
      if (!cfg.finalStatus?.trim()) err(`“${node.name}” needs a final status.`);
      break;
    default:
      break;
  }
  return out;
}

/* ── auto layout ───────────────────────────────────────────────────────── */

const COL_W = 340;
const ROW_H = 210;

/** Simple layered layout (BFS from Start). Keeps the canvas readable after a
 *  lot of manual dragging or an import. */
export function autoLayout(def: ProcessDefinition): ProcessDefinition {
  const nodes = def.nodes ?? [];
  if (!nodes.length) return def;
  const start = nodes.find((n) => n.type === "start") ?? nodes[0];
  const depth = new Map<string, number>([[start.id, 0]]);
  const queue = [start.id];
  const seen = new Set([start.id]);

  while (queue.length) {
    const id = queue.shift()!;
    const d = depth.get(id) ?? 0;
    for (const e of def.edges.filter((x) => x.from === id)) {
      if (!seen.has(e.to)) {
        seen.add(e.to);
        depth.set(e.to, d + 1);
        queue.push(e.to);
      }
    }
  }
  let orphanRow = 0;
  const rows = new Map<number, number>();
  const placed = nodes.map((n) => {
    const d = depth.get(n.id);
    if (d === undefined) {
      orphanRow += 1;
      return { ...n, x: 40, y: 40 + (orphanRow - 1) * ROW_H };
    }
    const col = rows.get(d) ?? 0;
    rows.set(d, col + 1);
    return { ...n, x: 380 + col * COL_W, y: 60 + d * ROW_H };
  });
  return { ...def, nodes: placed };
}

/* ── simulation ────────────────────────────────────────────────────────── */

export interface SimulationOptions {
  /** Sample form values keyed by field KEY. */
  values?: Record<string, unknown>;
  /** Decision to take at each assignment: nodeId → port id. Anything missing
   *  defaults to `defaultDecision`. */
  decisions?: Record<string, string>;
  defaultDecision?: string;
  context?: Record<string, unknown>;
  maxSteps?: number;
}

function applyAssignment(target: string, value: unknown, scope: EvalScope) {
  if (target.startsWith("var:")) scope.variables[target.slice(4)] = value;
  else if (target.startsWith("field:")) scope.values[target.slice(6)] = value;
  else scope.values[target] = value;
}

export function simulateProcess(def: ProcessDefinition, opts: SimulationOptions = {}): SimulationState {
  const scope = emptyScope({
    values: { ...(opts.values ?? {}) },
    context: {
      initiator_name: "Sample Initiator",
      initiator_email: "initiator@example.com",
      current_user: "Sample Initiator",
      ...(opts.context ?? {}),
    },
  });

  // Seed variables
  for (const v of def.variables ?? []) {
    scope.variables[v.key] = v.initial ? evaluateExpression(v.initial, scope) : "";
  }

  const trace: SimulationStep[] = [];
  const byId = new Map(def.nodes.map((n) => [n.id, n]));
  let current = def.nodes.find((n) => n.type === "start");
  if (!current) {
    return { ...scopeOut(scope), trace, finished: true, error: "No Start Process activity." };
  }

  const maxSteps = opts.maxSteps ?? 200;
  let steps = 0;
  let finalStatus: string | undefined;
  let error: string | undefined;
  const pendingBranches: string[] = [];

  while (current && steps < maxSteps) {
    steps += 1;
    const node: ProcessNode = current;
    const { port, detail, status } = runNode(node, scope, opts);
    trace.push({
      nodeId: node.id,
      nodeName: node.name,
      type: node.type,
      detail,
      outPort: port ?? undefined,
      awaiting: node.type === "assignment",
      status,
    });

    if (node.type === "completed" || node.type === "terminate") {
      finalStatus = (node.config as Extract<ActivityConfig, { kind: "completed" }>).finalStatus;
      break;
    }

    if (node.type === "fork") {
      const outs = def.edges.filter((e) => e.from === node.id);
      // Walk the first branch inline and queue the rest so every path is traced.
      outs.slice(1).forEach((e) => pendingBranches.push(e.to));
      current = outs[0] ? byId.get(outs[0].to) : undefined;
      if (!current) current = nextQueued();
      continue;
    }

    const edge = def.edges.find((e) => e.from === node.id && e.fromPort === port);
    if (!edge) {
      const queued = nextQueued();
      if (queued) { current = queued; continue; }
      error = `“${node.name}” has no connection on the “${port}” outcome.`;
      break;
    }
    current = byId.get(edge.to);
    if (!current) { error = "A connection points at a deleted activity."; break; }
  }

  if (steps >= maxSteps) error = "Simulation stopped — the graph appears to loop.";

  function nextQueued(): ProcessNode | undefined {
    while (pendingBranches.length) {
      const id = pendingBranches.shift()!;
      const n = byId.get(id);
      if (n) return n;
    }
    return undefined;
  }

  return { ...scopeOut(scope), trace, finished: !error, finalStatus, error };
}

function scopeOut(scope: EvalScope) {
  return { values: scope.values, variables: scope.variables, records: scope.records };
}

function runNode(
  node: ProcessNode,
  scope: EvalScope,
  opts: SimulationOptions,
): { port: string | null; detail: string; status?: string } {
  const cfg = node.config;
  switch (cfg.kind) {
    case "start":
      scope.context.status = cfg.statusLabel;
      return { port: "done", detail: `Submitted as “${cfg.statusLabel}”.`, status: cfg.statusLabel };

    case "assignment": {
      scope.context.status = cfg.statusLabel;
      if (cfg.skipWhen && evaluateRuleGroup(cfg.skipWhen, scope)) {
        return { port: "approved", detail: `Skipped (${describeRuleGroup(cfg.skipWhen)}).`, status: cfg.statusLabel };
      }
      if (cfg.autoApproveWhen && evaluateRuleGroup(cfg.autoApproveWhen, scope)) {
        return { port: "approved", detail: `Auto-approved (${describeRuleGroup(cfg.autoApproveWhen)}).`, status: cfg.statusLabel };
      }
      const chosen = opts.decisions?.[node.id] ?? opts.defaultDecision ?? "approved";
      const who = describeAssignee(cfg);
      return { port: chosen, detail: `Waiting on ${who} — simulated “${chosen}”.`, status: cfg.statusLabel };
    }

    case "notification": {
      if (cfg.sendWhen && !evaluateRuleGroup(cfg.sendWhen, scope)) {
        return { port: "done", detail: "Skipped — send condition not met." };
      }
      const to = [
        cfg.toInitiator ? "initiator" : null,
        ...(cfg.toEmails ?? []),
        ...(cfg.toGroups ?? []).map((g) => `group:${g}`),
        ...(cfg.toFieldKeys ?? []).map((f) => `{{field.${f}}}`),
      ].filter(Boolean).join(", ");
      return { port: "done", detail: `Email “${interpolate(cfg.subject, scope)}” → ${to || "nobody"}.` };
    }

    case "set_value": {
      const applied: string[] = [];
      for (const a of cfg.assignments ?? []) {
        if (a.when && !evaluateRuleGroup(a.when, scope)) continue;
        const value = a.mode === "constant" ? a.value : evaluateExpression(a.value, scope);
        applyAssignment(a.target, value, scope);
        applied.push(`${a.target} = ${String(value)}`);
      }
      return { port: "done", detail: applied.length ? applied.join("; ") : "Nothing to set." };
    }

    case "calculate": {
      const raw = evaluateExpression(cfg.expression, scope);
      const num = typeof raw === "number" ? Number(raw.toFixed(cfg.decimals ?? 2)) : raw;
      applyAssignment(cfg.target, num, scope);
      return { port: "done", detail: `${cfg.target} = ${String(num)}` };
    }

    case "if_else": {
      const result = evaluateRuleGroup(cfg.rules, scope);
      return { port: result ? "true" : "false", detail: `${describeRuleGroup(cfg.rules)} → ${result}` };
    }

    case "switch": {
      for (const c of cfg.cases ?? []) {
        if (evaluateRuleGroup(c.rules, scope)) return { port: c.id, detail: `Matched “${c.label}”.` };
      }
      return { port: "default", detail: "No case matched — default branch." };
    }

    case "get_record": {
      const record: Record<string, unknown> = {};
      for (const f of cfg.fields ?? []) record[f] = resolveRef(`field.${f}`, scope);
      record.status = scope.context.status ?? "";
      scope.records[cfg.alias] = record;
      return { port: "done", detail: `Loaded ${Object.keys(record).length} value(s) into ${cfg.alias}.` };
    }

    case "fork":
      return { port: null, detail: `Split into ${cfg.branches?.length ?? 0} parallel branches.` };

    case "join":
      return { port: "done", detail: cfg.mode === "all" ? "Waits for every branch." : "Continues on the first branch." };

    case "http_request":
    case "http_background":
      return { port: "done", detail: `Would ${cfg.method} ${interpolate(cfg.url, scope)}.` };

    case "http_receive":
      return { port: "done", detail: `Waits for a callback on /api/public/process/${cfg.token}.` };

    case "http_response":
      return { port: "done", detail: `Replies ${cfg.status}.` };

    case "data_connector": {
      if (cfg.runWhen && !evaluateRuleGroup(cfg.runWhen, scope)) {
        return { port: "done", detail: "Skipped — run condition not met." };
      }
      return { port: "done", detail: `Would post to ${cfg.connector}${cfg.stage ? ` (stage ${cfg.stage})` : ""}.` };
    }

    case "delay":
      return {
        port: "done",
        detail: cfg.mode === "duration" ? `Waits ${cfg.hours ?? 0}h.` : `Waits until ${cfg.untilRef}.`,
      };

    case "create_document":
      return { port: "done", detail: `Creates a document from template ${cfg.templateId || "—"}.` };

    case "sub_process":
      return { port: "done", detail: `Runs sub-process ${cfg.templateId || "—"}.` };

    case "script": {
      const lines = (cfg.body ?? "").split("\n").map((l) => l.trim()).filter(Boolean);
      for (const line of lines) {
        const [target, ...rest] = line.split("=");
        if (!rest.length) continue;
        applyAssignment(target.trim(), evaluateExpression(rest.join("="), scope), scope);
      }
      return { port: "done", detail: `Ran ${lines.length} assignment(s).` };
    }

    case "completed":
      scope.context.status = cfg.finalStatus;
      return { port: null, detail: `Process completed as “${cfg.finalStatus}”.`, status: cfg.finalStatus };

    case "terminate":
      scope.context.status = cfg.finalStatus;
      return { port: null, detail: `Process ended as “${cfg.finalStatus}”.`, status: cfg.finalStatus };

    default:
      return { port: "done", detail: ACTIVITY_META[node.type]?.description ?? "" };
  }
}

export function describeAssignee(cfg: Extract<ActivityConfig, { kind: "assignment" }>): string {
  switch (cfg.assigneeType) {
    case "group_any": return `anyone in ${cfg.assigneeGroupName || "the group"}`;
    case "group_all": return `everyone in ${cfg.assigneeGroupName || "the group"}`;
    case "group_specific": return `${cfg.assigneeUserName || "a user"} in ${cfg.assigneeGroupName || "the group"}`;
    case "user": return cfg.assigneeUserName || "a named user";
    case "initiator": return "the initiator";
    case "manager": return "the initiator's manager";
    case "field_user": return `the user in ${cfg.assigneeRef || "a field"}`;
    case "variable": return `the user in ${cfg.assigneeRef || "a variable"}`;
    default: return "an approver";
  }
}
