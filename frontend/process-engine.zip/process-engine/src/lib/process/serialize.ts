/**
 * serialize.ts — normalize (load) and output (save) a ProcessDefinition, plus
 * a one-way migration from your existing workflow templates.
 *
 * normalizeProcess() is idempotent and defensive: it accepts anything that
 * came back from the API — null, a legacy shape, a partially-written draft —
 * and returns a definition the builder can render without crashing.
 *
 * outputProcess() strips UI-only state and stamps the version so the backend
 * can branch on it.
 */

import type {
  ActivityConfig, ActivityType, DefaultColumn, ProcessDefinition, ProcessEdge,
  ProcessNode, ProcessVariable, RuleGroup, ProcessCondition,
} from "@/types/process";
import { ACTIVITY_META, blankProcess, defaultConfig, uid } from "./activities";

export const PROCESS_VERSION = 3;

/* ── rule groups ───────────────────────────────────────────────────────── */

export function normalizeRuleGroup(raw: unknown): RuleGroup | null {
  if (!raw || typeof raw !== "object") return null;
  const obj = raw as Record<string, unknown>;

  // Legacy single rule { fieldKey, operator, value }
  if (!Array.isArray(obj.conditions) && typeof obj.fieldKey === "string") {
    return {
      combinator: "and",
      conditions: [{
        source: "field",
        ref: `field.${obj.fieldKey}`,
        operator: (obj.operator as ProcessCondition["operator"]) ?? "equals",
        value: obj.value === undefined ? undefined : String(obj.value),
      }],
      groups: [],
    };
  }
  if (!Array.isArray(obj.conditions)) return null;

  return {
    combinator: obj.combinator === "or" ? "or" : "and",
    conditions: (obj.conditions as Record<string, unknown>[]).map((c) => {
      // Accept the TemplateBuilderV2 condition shape too (fieldKey/source).
      const legacyKey = typeof c.fieldKey === "string" ? c.fieldKey : undefined;
      const source = c.source === "variable" || c.source === "record"
        || c.source === "context" || c.source === "expression"
        ? (c.source as ProcessCondition["source"])
        : c.source === "process_step" ? "context" : "field";
      const ref = typeof c.ref === "string"
        ? c.ref
        : c.source === "process_step" ? "ctx.status"
        : legacyKey ? `field.${legacyKey}` : "";
      return {
        source,
        ref,
        operator: (c.operator as ProcessCondition["operator"]) ?? "equals",
        value: c.value === undefined ? undefined : String(c.value),
        value2: c.value2 === undefined ? undefined : String(c.value2),
      };
    }),
    groups: Array.isArray(obj.groups)
      ? (obj.groups as unknown[]).map(normalizeRuleGroup).filter((g): g is RuleGroup => !!g)
      : [],
  };
}

/* ── nodes ─────────────────────────────────────────────────────────────── */

function normalizeConfig(type: ActivityType, raw: unknown, index: number): ActivityConfig {
  const base = defaultConfig(type, index) as unknown as Record<string, unknown>;
  const incoming = (raw && typeof raw === "object" ? raw : {}) as Record<string, unknown>;
  const merged = { ...base, ...incoming, kind: type } as Record<string, unknown>;

  // Rule-group fields need their own normalization pass.
  for (const key of ["rules", "skipWhen", "autoApproveWhen", "sendWhen", "runWhen", "preconditions", "match"]) {
    if (key in merged) merged[key] = normalizeRuleGroup(merged[key]);
  }
  if (Array.isArray(merged.assignments)) {
    merged.assignments = (merged.assignments as Record<string, unknown>[]).map((a) => ({
      id: (a.id as string) || uid("asg"),
      target: (a.target as string) ?? "",
      mode: (a.mode as string) ?? "expression",
      value: (a.value as string) ?? "",
      when: normalizeRuleGroup(a.when),
    }));
  }
  if (Array.isArray(merged.cases)) {
    merged.cases = (merged.cases as Record<string, unknown>[]).map((c) => ({
      id: (c.id as string) || uid("case"),
      label: (c.label as string) ?? "Case",
      rules: normalizeRuleGroup(c.rules) ?? { combinator: "and", conditions: [], groups: [] },
    }));
  }
  return merged as unknown as ActivityConfig;
}

function normalizeNode(raw: unknown, index: number): ProcessNode | null {
  if (!raw || typeof raw !== "object") return null;
  const obj = raw as Record<string, unknown>;
  const type = (obj.type as ActivityType) ?? "set_value";
  if (!ACTIVITY_META[type]) return null;
  return {
    id: (obj.id as string) || uid(type),
    type,
    name: (obj.name as string) || ACTIVITY_META[type].label,
    description: (obj.description as string) ?? "",
    x: Number(obj.x) || 0,
    y: Number(obj.y) || 0,
    collapsed: Boolean(obj.collapsed),
    config: normalizeConfig(type, obj.config, index),
  };
}

function normalizeEdge(raw: unknown): ProcessEdge | null {
  if (!raw || typeof raw !== "object") return null;
  const obj = raw as Record<string, unknown>;
  if (!obj.from || !obj.to) return null;
  return {
    id: (obj.id as string) || uid("e"),
    from: String(obj.from),
    fromPort: String(obj.fromPort ?? "done"),
    to: String(obj.to),
    label: obj.label ? String(obj.label) : undefined,
  };
}

function normalizeVariable(raw: unknown): ProcessVariable | null {
  if (!raw || typeof raw !== "object") return null;
  const obj = raw as Record<string, unknown>;
  if (!obj.key) return null;
  return {
    id: (obj.id as string) || uid("var"),
    key: String(obj.key),
    label: (obj.label as string) || String(obj.key),
    type: (obj.type as ProcessVariable["type"]) ?? "text",
    initial: obj.initial === undefined ? "" : String(obj.initial),
    description: (obj.description as string) ?? "",
    exposed: Boolean(obj.exposed),
  };
}

export function normalizeProcess(raw: unknown): ProcessDefinition {
  if (!raw || typeof raw !== "object") return blankProcess();
  const obj = raw as Record<string, unknown>;
  const nodes = Array.isArray(obj.nodes)
    ? obj.nodes.map((n, i) => normalizeNode(n, i)).filter((n): n is ProcessNode => !!n)
    : [];
  if (!nodes.length) return blankProcess();

  const nodeIds = new Set(nodes.map((n) => n.id));
  const edges = (Array.isArray(obj.edges) ? obj.edges : [])
    .map(normalizeEdge)
    .filter((e): e is ProcessEdge => !!e && nodeIds.has(e.from) && nodeIds.has(e.to));

  return {
    version: Number(obj.version) || PROCESS_VERSION,
    nodes,
    edges,
    variables: (Array.isArray(obj.variables) ? obj.variables : [])
      .map(normalizeVariable).filter((v): v is ProcessVariable => !!v),
    settings: {
      legacyWorkflowTemplateId: (obj.settings as Record<string, unknown> | undefined)?.legacyWorkflowTemplateId as string ?? null,
      restartOnResubmit: Boolean((obj.settings as Record<string, unknown> | undefined)?.restartOnResubmit),
      instanceSlaHours: Number((obj.settings as Record<string, unknown> | undefined)?.instanceSlaHours) || undefined,
      notifyInitiatorOnStatusChange:
        (obj.settings as Record<string, unknown> | undefined)?.notifyInitiatorOnStatusChange !== false,
    },
  };
}

export function outputProcess(def: ProcessDefinition): ProcessDefinition {
  return {
    version: PROCESS_VERSION,
    nodes: def.nodes.map(({ collapsed: _collapsed, accent: _accent, ...n }) => ({
      ...n,
      x: Math.round(n.x),
      y: Math.round(n.y),
    })),
    edges: def.edges,
    variables: def.variables,
    settings: def.settings,
  };
}

/* ── default columns ───────────────────────────────────────────────────── */

export function normalizeDefaultColumns(raw: unknown): DefaultColumn[] {
  if (!Array.isArray(raw)) return [];
  return raw
    .filter((c): c is Record<string, unknown> => !!c && typeof c === "object")
    .map((c) => ({
      id: (c.id as string) || uid("col"),
      ref: String(c.ref ?? ""),
      label: (c.label as string) || String(c.ref ?? ""),
      width: Number(c.width) || undefined,
      visible: c.visible !== false,
      sortable: c.sortable !== false,
      filterable: Boolean(c.filterable),
      align: (c.align as DefaultColumn["align"]) ?? "left",
      format: (c.format as DefaultColumn["format"]) ?? "text",
    }))
    .filter((c) => c.ref);
}

/* ── migration from the old workflow templates ─────────────────────────── */

export interface LegacyWorkflowStep {
  id?: string;
  order: number;
  name: string;
  status_label: string;
  step_type: "approval" | "notification";
  assignee_type?: "group_any" | "group_all" | "group_specific";
  assignee_group?: string | null;
  assignee_group_name?: string;
  assignee_user?: string | null;
  assignee_user_name?: string;
  sla_hours?: number;
  allow_resubmit?: boolean;
  allow_approve?: boolean;
  allow_reject?: boolean;
  allow_return?: boolean;
  requires_signature?: boolean;
  instructions?: string;
  approver_email_subject?: string;
  approver_email_body?: string;
  notify_user?: string | null;
  notify_email?: string;
  notify_emails?: string[];
  notification_subject?: string;
  notification_message?: string;
  notify_include_items_table?: boolean;
}

/**
 * Convert one of your existing linear workflow templates into a graph so
 * nothing has to be re-authored by hand. Approval steps chain on "approved";
 * every "rejected" goes to a single Terminate node.
 */
export function migrateWorkflowTemplate(
  steps: LegacyWorkflowStep[],
  opts: { templateName?: string; finalStatus?: string } = {},
): ProcessDefinition {
  const ordered = [...steps].sort((a, b) => a.order - b.order);
  const nodes: ProcessNode[] = [];
  const edges: ProcessEdge[] = [];

  const start: ProcessNode = {
    id: uid("start"), type: "start", name: "Start Process",
    description: ACTIVITY_META.start.description, x: 380, y: 40,
    config: { kind: "start", statusLabel: "Submitted", preconditions: null, allowDraft: true },
  };
  nodes.push(start);

  const rejected: ProcessNode = {
    id: uid("terminate"), type: "terminate", name: "Rejected",
    description: "", x: 760, y: 300,
    config: { kind: "terminate", finalStatus: "Rejected", reason: "" },
  };

  let prev = start;
  let prevPort = "done";
  let y = 240;

  ordered.forEach((step) => {
    const node: ProcessNode = step.step_type === "notification"
      ? {
          id: uid("notification"), type: "notification", name: step.name || "Notification",
          description: "", x: 380, y,
          config: {
            kind: "notification", channel: "email",
            toUsers: step.notify_user ? [step.notify_user] : [],
            toGroups: [],
            toEmails: step.notify_emails ?? (step.notify_email ? [step.notify_email] : []),
            toFieldKeys: [], toInitiator: false,
            subject: step.notification_subject ?? "",
            body: step.notification_message ?? "",
            includeItemsTable: Boolean(step.notify_include_items_table),
            attachDocument: false, sendWhen: null,
          },
        }
      : {
          id: uid("assignment"), type: "assignment", name: step.name || step.status_label,
          description: "", x: 380, y,
          config: {
            kind: "assignment",
            statusLabel: step.status_label || step.name,
            assigneeType: step.assignee_type ?? "group_any",
            assigneeGroup: step.assignee_group ?? null,
            assigneeGroupName: step.assignee_group_name,
            assigneeUser: step.assignee_user ?? null,
            assigneeUserName: step.assignee_user_name,
            slaHours: step.sla_hours ?? 48,
            allowApprove: step.allow_approve !== false,
            allowReject: step.allow_reject !== false,
            allowReturn: Boolean(step.allow_return),
            allowResubmit: step.allow_resubmit !== false,
            requiresSignature: Boolean(step.requires_signature),
            requireComment: false,
            instructions: step.instructions ?? "",
            approverEmailSubject: step.approver_email_subject,
            approverEmailBody: step.approver_email_body,
            skipWhen: null, autoApproveWhen: null, access: [], escalation: null,
          },
        };

    nodes.push(node);
    edges.push({ id: uid("e"), from: prev.id, fromPort: prevPort, to: node.id });
    if (node.type === "assignment") {
      edges.push({ id: uid("e"), from: node.id, fromPort: "rejected", to: rejected.id, label: "Rejected" });
      prevPort = "approved";
    } else {
      prevPort = "done";
    }
    prev = node;
    y += 220;
  });

  const completed: ProcessNode = {
    id: uid("completed"), type: "completed", name: "CompletedProcess",
    description: "", x: 380, y,
    config: { kind: "completed", finalStatus: opts.finalStatus ?? "Approved", message: "", lockDocument: true },
  };
  nodes.push(completed, rejected);
  edges.push({ id: uid("e"), from: prev.id, fromPort: prevPort, to: completed.id });

  return {
    version: PROCESS_VERSION,
    nodes,
    edges,
    variables: [],
    settings: { restartOnResubmit: false, notifyInitiatorOnStatusChange: true },
  };
}
