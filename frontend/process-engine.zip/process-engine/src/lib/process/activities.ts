/**
 * activities.ts — the activity catalogue: palette metadata, outgoing ports,
 * and factory defaults. Everything the builder needs to know about an
 * activity type lives here, so adding a new activity is a one-file change
 * (plus a config panel in NodeConfigModal).
 */

import type {
  ActivityConfig, ActivityType, ProcessDefinition, ProcessNode,
} from "@/types/process";
import { emptyRuleGroup } from "./conditions";

export function uid(prefix = "n"): string {
  return `${prefix}_${Math.random().toString(36).slice(2, 10)}`;
}

export interface Port {
  id: string;
  label: string;
  tone: "neutral" | "positive" | "negative" | "warning";
}

export type ActivityGroup = "flow" | "people" | "data" | "integration" | "control";

export interface ActivityMeta {
  type: ActivityType;
  label: string;
  group: ActivityGroup;
  /** lucide-react icon name — resolved in the palette/node components. */
  icon: string;
  description: string;
  /** Tailwind classes for the card header strip. */
  accent: string;
  /** Fixed ports; dynamic ones (fork branches, switch cases) come from
   *  portsForNode() below. */
  ports: Port[];
  singleton?: boolean;
}

const DONE: Port[] = [{ id: "done", label: "Done", tone: "neutral" }];

export const ACTIVITY_META: Record<ActivityType, ActivityMeta> = {
  start: {
    type: "start", label: "Start Process", group: "flow", icon: "Play", singleton: true,
    description: "The first step of a business process.",
    accent: "bg-sky-50 border-sky-200 text-sky-900",
    ports: DONE,
  },
  assignment: {
    type: "assignment", label: "Assignment", group: "people", icon: "UsersRound",
    description: "Assign a stage to an individual or a group.",
    accent: "bg-emerald-50 border-emerald-200 text-emerald-900",
    ports: [
      { id: "approved", label: "Approved", tone: "positive" },
      { id: "rejected", label: "Rejected", tone: "negative" },
      { id: "returned", label: "Returned", tone: "warning" },
    ],
  },
  notification: {
    type: "notification", label: "Notification", group: "people", icon: "Bell",
    description: "Send an email or in-app notification.",
    accent: "bg-amber-50 border-amber-200 text-amber-900",
    ports: DONE,
  },
  set_value: {
    type: "set_value", label: "Set Value", group: "data", icon: "Pencil",
    description: "Set or change the value of a field or variable.",
    accent: "bg-slate-50 border-slate-200 text-slate-900",
    ports: DONE,
  },
  calculate: {
    type: "calculate", label: "Calculate", group: "data", icon: "Sigma",
    description: "Evaluate a formula and store the result.",
    accent: "bg-slate-50 border-slate-200 text-slate-900",
    ports: DONE,
  },
  if_else: {
    type: "if_else", label: "If/Else", group: "control", icon: "GitBranch",
    description: "Split the process into branches on a condition.",
    accent: "bg-violet-50 border-violet-200 text-violet-900",
    ports: [
      { id: "true", label: "True", tone: "positive" },
      { id: "false", label: "False", tone: "negative" },
    ],
  },
  switch: {
    type: "switch", label: "Switch", group: "control", icon: "ListOrdered",
    description: "Route down the first matching case (amount bands, categories).",
    accent: "bg-violet-50 border-violet-200 text-violet-900",
    ports: [],
  },
  get_record: {
    type: "get_record", label: "Get Current Record", group: "data", icon: "FileSearch",
    description: "Load data from the current or a related record for later steps.",
    accent: "bg-slate-50 border-slate-200 text-slate-900",
    ports: DONE,
  },
  fork: {
    type: "fork", label: "Fork", group: "control", icon: "Split",
    description: "Give the process two or more parallel paths.",
    accent: "bg-indigo-50 border-indigo-200 text-indigo-900",
    ports: [],
  },
  join: {
    type: "join", label: "Join", group: "control", icon: "Merge",
    description: "Join forked paths back into a single branch.",
    accent: "bg-indigo-50 border-indigo-200 text-indigo-900",
    ports: DONE,
  },
  http_request: {
    type: "http_request", label: "Send HTTP Request", group: "integration", icon: "Webhook",
    description: "Call an external API and wait for the response.",
    accent: "bg-cyan-50 border-cyan-200 text-cyan-900",
    ports: [
      { id: "done", label: "Done", tone: "neutral" },
      { id: "error", label: "Error", tone: "negative" },
    ],
  },
  http_background: {
    type: "http_background", label: "Send HTTP Background", group: "integration", icon: "Webhook",
    description: "Send a request in the background and resume when it completes.",
    accent: "bg-cyan-50 border-cyan-200 text-cyan-900",
    ports: [
      { id: "done", label: "Done", tone: "neutral" },
      { id: "error", label: "Error", tone: "negative" },
    ],
  },
  http_receive: {
    type: "http_receive", label: "Receive HTTP Request", group: "integration", icon: "Inbox",
    description: "Pause until an external system calls back.",
    accent: "bg-cyan-50 border-cyan-200 text-cyan-900",
    ports: [
      { id: "done", label: "Received", tone: "neutral" },
      { id: "timeout", label: "Timeout", tone: "warning" },
    ],
  },
  http_response: {
    type: "http_response", label: "Write HTTP Response", group: "integration", icon: "Send",
    description: "Reply to the caller of a received request.",
    accent: "bg-cyan-50 border-cyan-200 text-cyan-900",
    ports: DONE,
  },
  data_connector: {
    type: "data_connector", label: "Data Connector", group: "integration", icon: "Plug",
    description: "Post to SunSystems or another configured connector.",
    accent: "bg-fuchsia-50 border-fuchsia-200 text-fuchsia-900",
    ports: [
      { id: "done", label: "Done", tone: "neutral" },
      { id: "error", label: "Error", tone: "negative" },
    ],
  },
  delay: {
    type: "delay", label: "Wait", group: "flow", icon: "Clock",
    description: "Hold the process for a period or until a date.",
    accent: "bg-slate-50 border-slate-200 text-slate-900",
    ports: DONE,
  },
  create_document: {
    type: "create_document", label: "Create Document", group: "data", icon: "FilePlus2",
    description: "Raise a new document from another template.",
    accent: "bg-slate-50 border-slate-200 text-slate-900",
    ports: DONE,
  },
  sub_process: {
    type: "sub_process", label: "Sub Process", group: "flow", icon: "Workflow",
    description: "Run another template's process from here.",
    accent: "bg-slate-50 border-slate-200 text-slate-900",
    ports: DONE,
  },
  script: {
    type: "script", label: "Expression Block", group: "data", icon: "FileCode",
    description: "Run several assignments in one step.",
    accent: "bg-slate-50 border-slate-200 text-slate-900",
    ports: DONE,
  },
  completed: {
    type: "completed", label: "CompletedProcess", group: "flow", icon: "Flag",
    description: "Marks the business process as completed.",
    accent: "bg-teal-50 border-teal-200 text-teal-900",
    ports: [],
  },
  terminate: {
    type: "terminate", label: "Terminate", group: "flow", icon: "Ban",
    description: "End the process early (rejected / cancelled).",
    accent: "bg-rose-50 border-rose-200 text-rose-900",
    ports: [],
  },
};

export const ACTIVITY_GROUPS: { id: ActivityGroup; label: string }[] = [
  { id: "flow", label: "Flow" },
  { id: "people", label: "People" },
  { id: "control", label: "Conditions" },
  { id: "data", label: "Data" },
  { id: "integration", label: "Integrations" },
];

/** Ports including the dynamic ones driven by a node's own configuration. */
export function portsForNode(node: ProcessNode): Port[] {
  if (node.type === "fork") {
    const cfg = node.config as Extract<ActivityConfig, { kind: "fork" }>;
    return (cfg.branches ?? []).map((b) => ({ id: b.id, label: b.label, tone: "neutral" as const }));
  }
  if (node.type === "switch") {
    const cfg = node.config as Extract<ActivityConfig, { kind: "switch" }>;
    const cases = (cfg.cases ?? []).map((c) => ({ id: c.id, label: c.label, tone: "neutral" as const }));
    return cfg.hasDefault ? [...cases, { id: "default", label: "Default", tone: "warning" as const }] : cases;
  }
  if (node.type === "assignment") {
    const cfg = node.config as Extract<ActivityConfig, { kind: "assignment" }>;
    const out: Port[] = [];
    if (cfg.allowApprove !== false) out.push({ id: "approved", label: "Approved", tone: "positive" });
    if (cfg.allowReject !== false) out.push({ id: "rejected", label: "Rejected", tone: "negative" });
    if (cfg.allowReturn) out.push({ id: "returned", label: "Returned", tone: "warning" });
    if (cfg.escalation?.enabled) out.push({ id: "escalated", label: "Escalated", tone: "warning" });
    return out.length ? out : [{ id: "done", label: "Done", tone: "neutral" }];
  }
  if (node.type === "if_else") {
    const cfg = node.config as Extract<ActivityConfig, { kind: "if_else" }>;
    return [
      { id: "true", label: cfg.trueLabel || "True", tone: "positive" },
      { id: "false", label: cfg.falseLabel || "False", tone: "negative" },
    ];
  }
  return ACTIVITY_META[node.type].ports;
}

/* ── factory ───────────────────────────────────────────────────────────── */

export function defaultConfig(type: ActivityType, index = 0): ActivityConfig {
  switch (type) {
    case "start":
      return { kind: "start", statusLabel: "Submitted", preconditions: null, allowDraft: true };
    case "assignment":
      return {
        kind: "assignment", statusLabel: "Pending Approval", assigneeType: "group_any",
        assigneeGroup: null, assigneeUser: null, slaHours: 48,
        allowApprove: true, allowReject: true, allowReturn: true, allowResubmit: true,
        requiresSignature: false, requireComment: false, instructions: "",
        skipWhen: null, autoApproveWhen: null, access: [], escalation: null,
      };
    case "notification":
      return {
        kind: "notification", channel: "both", toUsers: [], toGroups: [], toEmails: [],
        toFieldKeys: [], toInitiator: true, subject: "", body: "",
        includeItemsTable: false, attachDocument: false, sendWhen: null,
      };
    case "set_value":
      return { kind: "set_value", assignments: [] };
    case "calculate":
      return { kind: "calculate", target: "", expression: "", decimals: 2 };
    case "if_else":
      return { kind: "if_else", rules: emptyRuleGroup(), trueLabel: "True", falseLabel: "False" };
    case "switch":
      return { kind: "switch", cases: [{ id: uid("case"), label: "Case 1", rules: emptyRuleGroup() }], hasDefault: true };
    case "get_record":
      return { kind: "get_record", alias: `GCR${index}`, source: "current", fields: [], match: null, requireMatch: false };
    case "fork":
      return { kind: "fork", branches: [{ id: uid("br"), label: "Branch 1" }, { id: uid("br"), label: "Branch 2" }] };
    case "join":
      return { kind: "join", mode: "all" };
    case "http_request":
    case "http_background":
      return {
        kind: type as "http_request", method: "POST", url: "", headers: [],
        body: "", auth: { type: "none" }, timeoutSeconds: 30, retries: 0,
        responseMapping: [], continueOnError: false,
      } as ActivityConfig;
    case "http_receive":
      return { kind: "http_receive", token: uid("hook"), secretHeader: "", mapping: [], timeoutHours: 72 };
    case "http_response":
      return { kind: "http_response", status: 200, body: "{\"ok\": true}", contentType: "application/json" };
    case "data_connector":
      return { kind: "data_connector", connector: "sunsystems_journal", label: "JournalPosting", stage: 1, parameters: [], mapping: [], runWhen: null, continueOnError: false };
    case "delay":
      return { kind: "delay", mode: "duration", hours: 24, workingHours: true };
    case "create_document":
      return { kind: "create_document", templateId: "", titleExpression: "", documentTypeId: null, mapping: [], startProcess: true };
    case "sub_process":
      return { kind: "sub_process", templateId: "", waitForCompletion: true, mapping: [] };
    case "script":
      return { kind: "script", language: "expression", body: "" };
    case "completed":
      return { kind: "completed", finalStatus: "Completed", message: "", lockDocument: true };
    case "terminate":
      return { kind: "terminate", finalStatus: "Rejected", reason: "" };
    default:
      return { kind: "set_value", assignments: [] };
  }
}

export function createNode(type: ActivityType, x: number, y: number, index = 0): ProcessNode {
  const meta = ACTIVITY_META[type];
  return {
    id: uid(type),
    type,
    name: type === "get_record" ? `GCR${index}` : meta.label,
    description: meta.description,
    x: Math.round(x),
    y: Math.round(y),
    config: defaultConfig(type, index),
  };
}

/** A brand-new process: Start → Approval → Completed, already wired. */
export function blankProcess(): ProcessDefinition {
  const start = createNode("start", 360, 60);
  const approval = createNode("assignment", 360, 260);
  approval.name = "Approval";
  const done = createNode("completed", 360, 520);
  const reject = createNode("terminate", 700, 400);
  return {
    version: 3,
    nodes: [start, approval, done, reject],
    edges: [
      { id: uid("e"), from: start.id, fromPort: "done", to: approval.id, label: "Done" },
      { id: uid("e"), from: approval.id, fromPort: "approved", to: done.id, label: "Approved" },
      { id: uid("e"), from: approval.id, fromPort: "rejected", to: reject.id, label: "Rejected" },
    ],
    variables: [],
    settings: { restartOnResubmit: false, notifyInitiatorOnStatusChange: true },
  };
}
