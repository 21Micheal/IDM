/**
 * refOptions.ts — builds the "what can I reference?" lists used by every
 * condition picker, value target picker and token helper in the Process tab.
 *
 * It reads a minimal view of your TemplateBuilderV2 sections so the package
 * does not import the 300 KB builder file. TemplateSection / TemplateField are
 * structurally compatible with ProcessFormSection / ProcessFormField.
 */

import type { ProcessDefinition } from "@/types/process";
import type { RefOption } from "@/components/process/RuleGroupEditor";

export interface ProcessFormField {
  key?: string;
  id?: string;
  label?: string;
  type?: string;
  /** Table/repeater columns, if your table field nests them. */
  columns?: { key?: string; label?: string }[];
}

export interface ProcessFormSection {
  id: string;
  title: string;
  fields: ProcessFormField[];
}

const LAYOUT_TYPES = new Set(["heading", "divider", "spacer", "paragraph", "html", "budget"]);

export const CONTEXT_REFS: RefOption[] = [
  { value: "ctx.status", label: "Current status", group: "Process" },
  { value: "ctx.initiator_name", label: "Initiator name", group: "Process" },
  { value: "ctx.initiator_email", label: "Initiator email", group: "Process" },
  { value: "ctx.initiator_department", label: "Initiator department", group: "Process" },
  { value: "ctx.current_user", label: "Current user", group: "Process" },
  { value: "ctx.last_action", label: "Last action (approved/rejected/returned)", group: "Process" },
  { value: "ctx.last_comment", label: "Last approver comment", group: "Process" },
  { value: "ctx.step_count", label: "Steps completed", group: "Process" },
  { value: "ctx.resubmit_count", label: "Times resubmitted", group: "Process" },
  { value: "ctx.document_number", label: "Document number", group: "Process" },
  { value: "ctx.now", label: "Now (date/time)", group: "Process" },
];

export function formFields(sections: ProcessFormSection[]): { key: string; label: string; type: string; section: string }[] {
  const out: { key: string; label: string; type: string; section: string }[] = [];
  for (const s of sections ?? []) {
    for (const f of s.fields ?? []) {
      const key = f.key || f.id;
      if (!key || LAYOUT_TYPES.has(f.type ?? "")) continue;
      out.push({ key, label: f.label || key, type: f.type ?? "text", section: s.title });
    }
  }
  return out;
}

/** Options for condition left-hand sides and token pickers. */
export function buildRefOptions(sections: ProcessFormSection[], def: ProcessDefinition): RefOption[] {
  const opts: RefOption[] = [];
  for (const f of formFields(sections)) {
    opts.push({ value: `field.${f.key}`, label: `${f.label}`, group: `Form · ${f.section}` });
  }
  for (const v of def.variables ?? []) {
    opts.push({ value: `var.${v.key}`, label: v.label || v.key, group: "Variables" });
  }
  for (const n of def.nodes ?? []) {
    if (n.config.kind !== "get_record") continue;
    const alias = n.config.alias;
    opts.push({ value: `${alias}.status`, label: `${alias}.status`, group: `Record ${alias}` });
    for (const f of n.config.fields ?? []) {
      opts.push({ value: `${alias}.${f}`, label: `${alias}.${f}`, group: `Record ${alias}` });
    }
  }
  return [...opts, ...CONTEXT_REFS];
}

/** Writable targets for Set Value / Calculate / response mappings. */
export function buildTargetOptions(sections: ProcessFormSection[], def: ProcessDefinition): RefOption[] {
  return [
    ...formFields(sections).map((f) => ({ value: `field:${f.key}`, label: f.label, group: `Form · ${f.section}` })),
    ...(def.variables ?? []).map((v) => ({ value: `var:${v.key}`, label: v.label || v.key, group: "Variables" })),
  ];
}

/** Turn a ref option ("field.amount") into an insertable token ("{{field.amount}}"). */
export const toToken = (ref: string) => `{{${ref}}}`;
